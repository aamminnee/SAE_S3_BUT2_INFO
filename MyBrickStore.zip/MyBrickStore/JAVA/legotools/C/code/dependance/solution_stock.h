#ifndef SOLUTION_STOCK_H
#define SOLUTION_STOCK_H

#include "image.h"
#include "brique.h"
#include "structure.h"

Solution run_algo_stock(Image* I, BriqueList* B);

#endif