package fr.univ_eiffel.legotools.paving;

import fr.univ_eiffel.legotools.model.LegoBrick;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class PavingService {

    private final String pathToCExecutable;
    // On cible le dossier SAE à la racine du projet
    private final File saeDir = new File("SAE");
    private final File inputDir = new File(saeDir, "input");
    private final File outputDir = new File(saeDir, "output");

    public PavingService(String pathToCExecutable) {
        this.pathToCExecutable = pathToCExecutable;
        // Création des dossiers si inexistants (sécurité)
        if (!inputDir.exists()) inputDir.mkdirs();
        if (!outputDir.exists()) outputDir.mkdirs();
    }

    public BufferedImage generatePaving(BufferedImage sourceImage, String algoName) throws IOException, InterruptedException {
        // 1. Écrire le fichier image.txt dans SAE/input
        writeImageTxt(sourceImage);

        // 2. Préparer l'exécution du programme C
        // L'argument input est simplement "input" car on exécute depuis le dossier SAE
        String inputArg = "input"; 
        
        // Nettoyage du chemin de l'exécutable pour qu'il soit relatif au dossier SAE
        String exeCmd = pathToCExecutable;
        if (exeCmd.startsWith("./SAE/") || exeCmd.startsWith("SAE/")) {
            exeCmd = exeCmd.replace("SAE/", "");
            if (exeCmd.startsWith("./")) exeCmd = exeCmd.substring(2);
        }
        // Si l'utilisateur a donné un chemin absolu ou juste "code/exec/pavage", on gère le "./"
        if (!exeCmd.startsWith("./") && !exeCmd.startsWith("/")) {
            exeCmd = "./" + exeCmd;
        }

        System.out.println("Lancement C (dir=" + saeDir.getAbsolutePath() + ") : " + exeCmd + " " + inputArg + " " + algoName);
        
        ProcessBuilder pb = new ProcessBuilder(
                exeCmd,        // Commande (ex: ./code/exec/pavage)
                inputArg,      // Argument 1 : dossier input
                algoName       // Argument 2 : algorithme
        );
        
        // IMPORTANT : On se place dans le dossier SAE pour l'exécution
        pb.directory(saeDir);
        
        // Redirection de la sortie pour voir les logs du C dans la console Java
        pb.redirectErrorStream(true);
        pb.redirectOutput(ProcessBuilder.Redirect.INHERIT);

        Process process = pb.start();
        int exitCode = process.waitFor();

        if (exitCode != 0) {
            throw new IOException("Le programme C a échoué (Code " + exitCode + ")");
        }

        // 3. Lire le résultat depuis SAE/output/pavage_<algo>.txt
        String resultFileName = "pavage_" + algoName + ".txt";
        File resultFile = new File(outputDir, resultFileName);

        if (!resultFile.exists()) {
             throw new IOException("Résultat introuvable : " + resultFile.getAbsolutePath());
        }

        List<LegoBrick> bricks = parsePavingFile(resultFile);

        // 4. Générer l'image de prévisualisation
        return renderPreview(sourceImage.getWidth(), sourceImage.getHeight(), bricks);
    }

    // Génère le fichier image.txt au format attendu par votre C : Largeur Hauteur \n Pixels Hexa
    private void writeImageTxt(BufferedImage img) throws IOException {
        File file = new File(inputDir, "image.txt");
        try (PrintWriter writer = new PrintWriter(new FileWriter(file))) {
            int w = img.getWidth();
            int h = img.getHeight();
            // Ligne 1 : Largeur Hauteur
            writer.println(w + " " + h);

            // Lignes suivantes : La matrice de pixels hexadécimaux
            for (int y = 0; y < h; y++) {
                for (int x = 0; x < w; x++) {
                    int rgb = img.getRGB(x, y) & 0xFFFFFF;
                    writer.printf("%06X ", rgb);
                }
                writer.println();
            }
        }
    }

    // Lit le fichier de résultat ligne par ligne (Optimisé pour éviter OutOfMemoryError)
    private List<LegoBrick> parsePavingFile(File file) throws IOException {
        List<LegoBrick> bricks = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line = br.readLine(); // Lire la première ligne (stats)
            if (line != null) {
                System.out.println("Stats pavage : " + line);
            }

            while ((line = br.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty()) continue;

                // Format ligne : DIM/COLOR X Y ROT (ex: 2x2/FF0000 0 0 0)
                String[] parts = line.split(" ");
                if (parts.length < 4) continue;

                String[] typeAndColor = parts[0].split("/");
                if (typeAndColor.length < 2) continue; 
                
                String dims = typeAndColor[0];
                String color = typeAndColor[1];
                
                // Parsing des dimensions (ex: "2x2" ou "3x3-0101")
                String[] wh = dims.split("-")[0].split("x");
                int w = Integer.parseInt(wh[0]);
                int h = Integer.parseInt(wh[1]);
                
                int x = Integer.parseInt(parts[1]);
                int y = Integer.parseInt(parts[2]);
                int rot = Integer.parseInt(parts[3]);

                // Si rotation = 1, on inverse largeur et hauteur pour le dessin
                if (rot == 1) {
                    int temp = w; w = h; h = temp;
                }

                bricks.add(new LegoBrick(x, y, w, h, "#" + color));
            }
        }
        return bricks;
    }

    private BufferedImage renderPreview(int width, int height, List<LegoBrick> bricks) {
        // Adaptation dynamique du zoom pour éviter de créer des images trop lourdes
        int scale = 20;
        if (width > 200) scale = 5;
        if (width > 1000) scale = 1;

        System.out.println("Génération image prévisualisation " + (width*scale) + "x" + (height*scale));

        BufferedImage preview = new BufferedImage(width * scale, height * scale, BufferedImage.TYPE_INT_RGB);
        Graphics2D g2d = preview.createGraphics();

        // Fond noir
        g2d.setColor(Color.BLACK);
        g2d.fillRect(0, 0, width * scale, height * scale);

        for (LegoBrick brick : bricks) {
            try {
                g2d.setColor(Color.decode(brick.getColor()));
            } catch (NumberFormatException e) {
                g2d.setColor(Color.MAGENTA); // Couleur d'erreur si hex invalide
            }
            g2d.fillRect(brick.getX() * scale, brick.getY() * scale, 
                         brick.getWidth() * scale, brick.getHeight() * scale);
            
            // On ne dessine les contours que si le zoom est suffisant
            if (scale > 2) {
                g2d.setColor(Color.DARK_GRAY);
                g2d.drawRect(brick.getX() * scale, brick.getY() * scale, 
                             brick.getWidth() * scale, brick.getHeight() * scale);
            }
        }
        g2d.dispose();
        return preview;
    }
}