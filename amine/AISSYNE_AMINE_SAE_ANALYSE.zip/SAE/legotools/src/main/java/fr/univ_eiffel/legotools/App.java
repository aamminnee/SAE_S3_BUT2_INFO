package fr.univ_eiffel.legotools;

import fr.univ_eiffel.legotools.factory.StockManager;
import fr.univ_eiffel.legotools.factory.api.AccountRefiller;
import fr.univ_eiffel.legotools.factory.impl.HttpRestFactory;
import fr.univ_eiffel.legotools.model.FactoryBrick;
import fr.univ_eiffel.legotools.image.*;
import fr.univ_eiffel.legotools.paving.PavingService;
import io.github.cdimascio.dotenv.Dotenv; 

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Map;
import javax.imageio.ImageIO;

public class App {

    // Charge le .env (ignore s'il est absent pour éviter de planter en prod)
    private static final Dotenv dotenv = Dotenv.configure().ignoreIfMissing().load();

    // Méthode utilitaire : cherche dans .env, sinon dans le système
    private static String getEnv(String key) {
        String value = dotenv.get(key);
        if (value == null) {
            return System.getenv(key);
        }
        return value;
    }

    public static void main(String[] args) {
        if (args.length < 1) {
            printUsage();
            return;
        }

        String command = args[0];

        try {
            switch (command) {
                case "refill" -> runRefill();
                case "resize" -> runResize(args);
                case "pave" -> runPave(args);
                case "order" -> runOrder();
                default -> {
                    System.err.println("Commande inconnue : " + command);
                    printUsage();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void printUsage() {
        System.out.println("Usage :");
        System.out.println("  1. Recharger le compte : java -jar legotools.jar refill");
        System.out.println("  2. Redimensionner : java -jar legotools.jar resize <input> <output> <WxH> [strategy]");
        System.out.println("  3. Paver : java -jar legotools.jar pave <input> <output> <exe_c> <algo>");
        System.out.println("  4. Commander : java -jar legotools.jar order");
    }

    private static void runRefill() throws IOException {
        // MODIFICATION ICI : On utilise getEnv() au lieu de System.getenv()
        var email = getEnv("LEGOFACTORY_EMAIL");
        var key = getEnv("LEGOFACTORY_KEY");

        if (email == null || key == null) {
            System.err.println("Erreur : Variables LEGOFACTORY manquantes dans le .env ou le système.");
            return;
        }
        var refiller = new AccountRefiller(email, key);
        System.out.println("Nouveau solde : " + refiller.refill());
    }

    private static void runResize(String[] args) throws IOException {
        if (args.length < 4) {
            System.out.println("Usage: resize <input> <output> <WxH> [strategy]");
            return;
        }
        String input = args[1];
        String output = args[2];
        String[] dims = args[3].split("x");
        int w = Integer.parseInt(dims[0]);
        int h = Integer.parseInt(dims[1]);
        String algo = (args.length > 4) ? args[4].toLowerCase() : "neighbor";

        ImageProcessor processor = new ImageProcessor();
        switch (algo) {
            case "bilinear" -> processor.setStrategy(new BilinearStrategy());
            case "bicubic" -> processor.setStrategy(new BicubicStrategy());
            case "stepwise" -> processor.setStrategy(new StepwiseStrategy(List.of(new BilinearStrategy()), 3));
            case "neighbor" -> processor.setStrategy(new NearestNeighborStrategy());
            default -> System.out.println("Stratégie inconnue, utilisation de NearestNeighbor.");
        }
        processor.processImage(input, output, w, h);
    }

    private static void runPave(String[] args) throws IOException, InterruptedException {
        if (args.length < 5) {
            System.out.println("Usage: pave <input> <output> <exe_c> <algo>");
            return;
        }
        // ... (Le reste de runPave ne change pas)
        String inputPath = args[1];
        String outputPath = args[2];
        String exePath = args[3];
        String algoName = args[4];

        BufferedImage source = ImageIO.read(new File(inputPath));
        if (source == null) throw new IOException("Image introuvable : " + inputPath);

        PavingService service = new PavingService(exePath);
        BufferedImage result = service.generatePaving(source, algoName);

        ImageIO.write(result, "png", new File(outputPath));
        System.out.println("Pavage généré avec succès : " + outputPath);
    }

    private static void runOrder() {
        var email = getEnv("LEGOFACTORY_EMAIL");
        var key = getEnv("LEGOFACTORY_KEY");
        if (email == null) return;

        // 1. Instanciation
        HttpRestFactory factory = new HttpRestFactory(email, key);
        // On pourrait changer la stratégie ici : factory.setPaymentStrategy(new CreditCardStrategy());
        
        StockManager stock = new StockManager();
        stock.showStock();

        try {
            long balance = factory.getBalance();
            System.out.println("Solde : " + balance);

            if (balance < 100) {
                factory.rechargeAccount(100);
            }

            Map<String, Integer> panier = Map.of("2-2/c9cae2", 1);
            String quoteId = factory.requestQuote(panier);
            factory.acceptQuote(quoteId);
            
            System.out.println("Attente livraison...");
            List<FactoryBrick> briques = List.of();
            while (briques.isEmpty()) {
                briques = factory.retrieveOrder(quoteId);
                if (briques.isEmpty()) Thread.sleep(1000);
            }
            
            // 2. Vérification et Stockage
            System.out.println("Réception de " + briques.size() + " briques.");
            List<FactoryBrick> verifiedBricks = new java.util.ArrayList<>();
            
            for (FactoryBrick b : briques) {
                if (factory.verifyBrick(b)) {
                    System.out.println("✅ Brique authentique : " + b.serial());
                    verifiedBricks.add(b);
                } else {
                    System.err.println("❌ ALERTE : Brique contrefaite détectée ! " + b.serial());
                }
            }

            // 3. Sauvegarde dans le stock local
            stock.addBricks(verifiedBricks);
            stock.showStock();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}