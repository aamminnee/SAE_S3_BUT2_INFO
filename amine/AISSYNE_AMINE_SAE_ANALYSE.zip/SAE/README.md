LegoTools - Application de Pavage et Commande Lego

LegoTools est une application hybride Java/C permettant de transformer des images en plans de construction Lego, d'optimiser les coûts de fabrication et de commander les pièces nécessaires via une API distante.

Prérequis Techniques

Java 21 (Minimum requis)

Maven (Pour la construction du projet Java)

GCC & Make (Pour la compilation du module C)

Connexion Internet (Requise pour les commandes à l'usine)

Installation et Compilation

L'application nécessite une compilation en deux étapes : d'abord le moteur de calcul (C), puis l'orchestrateur (Java).

1. Configuration des Clés API

Créez un fichier nommé .env à la racine du dossier legotools contenant vos identifiants :

LEGOFACTORY_EMAIL=votre.email@edu.univ-eiffel.fr
LEGOFACTORY_KEY=votre_cle_secrete


2. Compilation du Module C

Le moteur de pavage se trouve dans le dossier SAE.

cd SAE
make clean
make
cd ..


Vérification : Cela doit générer l'exécutable ./SAE/code/exec/pavage.

3. Compilation du Projet Java

mvn clean package


Vérification : Cela génère l'archive ./target/legotools-1.0-SNAPSHOT.jar.

Guide d'Utilisation

Toutes les commandes s'exécutent via le fichier JAR généré.

A. Redimensionner une image (resize)

Adapte une image haute définition vers une résolution compatible Lego (ex: 128x128) pour éviter les problèmes de mémoire.

java -jar target/legotools-1.0-SNAPSHOT.jar resize <source> <destination> <largeur>x<hauteur> <strategie>


Exemple : java -jar target/legotools-1.0-SNAPSHOT.jar resize input/photo.jpg input/small.jpg 128x128 bicubic

Stratégies : neighbor, bilinear, bicubic, stepwise.

PS : stepwise = l'algo pour utiliser tout les autres algos pour modifier l ataille de l'image


B. Générer le Pavage (pave)

Calcule les briques nécessaires en utilisant l'algorithme C spécifié.

java -jar target/legotools-1.0-SNAPSHOT.jar pave <image_reduite> <sortie_visuelle> <chemin_exe_c> <algo>


Exemple : java -jar target/legotools-1.0-SNAPSHOT.jar pave input/small.jpg output/plan.png ./SAE/code/exec/pavage rectfusion

Algorithmes C : 1x1, greedy_1x2, rectfusion, forme_rentable.

C. Commander les pièces (order)

Vérifie le solde, mine des crédits (Proof of Work) si nécessaire, passe commande et vérifie l'authenticité des briques reçues.

java -jar target/legotools-1.0-SNAPSHOT.jar order


Les briques reçues sont sauvegardées dans stock.json.

Organisation des Dossiers

src/main/java : Code source Java (Architecture MVC + Strategy).

SAE/ : Code source C (Moteur de calcul).

input/ : Dossier contenant les images sources et la configuration briques.txt.

output/ : Dossier recevant les rapports de pavage et les images générées.
