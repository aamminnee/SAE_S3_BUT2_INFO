#ifndef SOLUTION_H
#define SOLUTION_H

#include "structure.h"

Solution run_algo_1x1(Image* I, BriqueList* B);

#endif
