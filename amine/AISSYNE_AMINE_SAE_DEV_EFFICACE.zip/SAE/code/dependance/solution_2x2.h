#ifndef SOLUTION_2X2_H
#define SOLUTION_2X2_H

#include "image.h"
#include "brique.h"
#include "matching.h"

Solution run_algo_2x2(Image* I, BriqueList* B);

#endif
