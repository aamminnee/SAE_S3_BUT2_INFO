#ifndef SOLUTION_FORME_ARBITRAIRE_RENTABLE_H
#define SOLUTION_FORME_ARBITRAIRE_RENTABLE_H

#include "image.h"
#include "brique.h"
#include "structure.h"

Solution run_algo_forme_rentable(Image* I, BriqueList* B);

#endif
