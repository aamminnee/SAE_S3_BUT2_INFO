<?php
// determine the protocol (http or https) based on server environment
if (!empty($_SERVER['HTTPS']) && ('on' == $_SERVER['HTTPS'])) {
    $uri = 'https://';
} else {
    $uri = 'http://';
}

// redirect to the images view and terminate the script
header('Location: views/images_views.php');
exit;
?>