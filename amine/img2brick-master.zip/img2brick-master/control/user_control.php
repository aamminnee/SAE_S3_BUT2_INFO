<?php
// start session
session_start();

// prevent multiple inclusion
if (!defined('USER_CONTROL_INCLUDED')) {
    define('USER_CONTROL_INCLUDED', true);
}

require_once __DIR__ . '/../models/users_models.php';
require_once __DIR__ . '/../models/tokens_models.php';
require_once __DIR__ . '/../vendor/autoload.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use Dotenv\Dotenv;

// load environment variables
$dotenv = Dotenv::createImmutable(__DIR__ . '/../');
$dotenv->load();

class UserController {
    private $user_model;
    private $token_model;
    private $mail;
    private $translations;

    // initialize models, mailer component and load translations based on session language
    public function __construct() {
        // initialize models and mailer
        $this->user_model = new UsersModel();
        $this->token_model = new TokensModel();
        $this->mail = new PHPMailer(true);
        $lang = $_SESSION['lang'] ?? 'fr';
        require_once __DIR__ . '/../models/translation_models.php';
        $translation_model = new TranslationModel();
        $this->translations = $translation_model->getTranslations($lang);
    }

    // helper function to retrieve translated strings
    private function t($key, $default = '') {
        return $this->translations[$key] ?? $default;
    }

    // process user login: validate captcha, verify credentials, and handle 2fa redirection if enabled
    public function login() {
        if (session_status() === PHP_SESSION_NONE) session_start();
        session_regenerate_id(true);

        if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['username']) && !empty($_POST['password'])) {
            // validate captcha
            $userCaptcha = $_POST['captcha'] ?? '';
            $token = $_POST['captcha_token'] ?? '';
            if (empty($token) || empty($userCaptcha) || strcasecmp(trim($userCaptcha), trim($token)) !== 0) {
                $message = $this->t('captcha_invalid', "Incorrect captcha. Please try again.");
                include __DIR__ . '/../views/login_views.php';
                return;
            }

            // process login
            $username = trim($_POST['username']);
            $password = $_POST['password'];
            $user = $this->user_model->getUserByUsername($username);

            if ($user && password_verify($password, $user['mdp'])) {
                // Get mode (2FA or null)
                $mode = $this->user_model->getModeById($user['id_user']);                
                if ($mode === '2FA') {
                    $_SESSION['temp_2fa_user_id'] = $user['id_user'];
                    $_SESSION['temp_2fa_email']   = $this->user_model->getEmailById($user['id_user'])['email'];
                    // generate and send 2FA token
                    $token = $this->token_model->generateToken($user['id_user'], "2FA");
                    $this->sendVerificationEmail($_SESSION['temp_2fa_email'], $token);
                    // redirect to token verification page
                    header("Location: ../views/verify_views.php");
                    exit;
                }
                $_SESSION['username'] = $username;
                $_SESSION['user_id']  = $user['id_user'];
                $_SESSION['email']    = $this->user_model->getEmailById($user['id_user'])['email'];
                $_SESSION['status']   = $this->user_model->getStatusById($user['id_user'])['etat'];
                $_SESSION['mode']     = $mode;
                header("Location: ../views/images_views.php");
                exit;
            } else {
                $message = $this->t('login_error', "Incorrect username or password.");
                include __DIR__ . '/../views/login_views.php';
            }
        } else {
            include __DIR__ . '/../views/login_views.php';
        }
    }

    // process new user registration with password complexity check and duplicate user validation
    public function register() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['email'], $_POST['username'], $_POST['password'])) {
            $email = trim($_POST['email']);
            $username = trim($_POST['username']);
            $password = $_POST['password'];
            // validate password format
            $passwordPattern = '/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[\W_]).{8,}$/';
            if (!preg_match($passwordPattern, $password)) {
                $message = $this->t('password_invalid', 
                    "Le mot de passe doit contenir au moins 8 caractères, dont une majuscule, une minuscule, un chiffre et un caractère spécial."
                );
                include __DIR__ . '/../views/register_views.php';
                return;
            }

            // try adding user
            $result = $this->user_model->addUser($email, $username, $password);
            if ($result === true) {
                $user = $this->user_model->getUserByUsername($username);
                $token = $this->token_model->generateToken($user['id_user'], "validation");
                $this->sendVerificationEmail($email, $token);
                header("Location: ../views/verify_views.php");
                exit;
            } elseif ($result === "duplicate") {
                $_SESSION['register_message'] = $this->t('username_exists', "Ce nom d'utilisateur ou l'adresse email existe déjà. Veuillez en choisir un autre.");
                header("Location: ../views/register_views.php");
                exit;
            } else {
                 $_SESSION['register_message'] = $this->t('register_error', "L'inscription a échoué, veuillez réessayer.");
                header("Location: ../views/register_views.php");
                exit;
            }
        } else {
            header("Location: ../views/register_views.php");
            exit;
        }
    }

    // process the password reset form submission and update the user password
    public function resetPasswordForm() {
        if (isset($_POST['reset_password'], $_POST['password'], $_POST['password_confirm'])) {
            $password = $_POST['password'];
            $password_confirm = $_POST['password_confirm'];

            // check if user is logged in
            if (!isset($_SESSION['user_id'])) {
                 header("Location: ../views/login_views.php");
                 exit;
            }
            if ($password === $password_confirm) {
                $this->user_model->setPassword($_SESSION['user_id'], $password);
                $message = $this->t('password_reset_success', "Password reset successfully.");
                include __DIR__ . '/../views/images_views.php';
            } else {
                $message = $this->t('password_mismatch', "Passwords do not match.");
                include __DIR__ . '/../views/reset_password_views.php';
            }
        } else {
            include __DIR__ . '/../views/reset_password_views.php';
        }
    }

    // generate a token and send the password reset email
    public function resetPassword() {
        if (!isset($_SESSION['user_id'])) {
            header("Location: ../views/login_views.php");
            exit;
        }
        $token = $this->token_model->generateToken($_SESSION['user_id'], "reinitialisation");
        $this->sendVerificationEmail($_SESSION['email'], $token);
        include __DIR__ . '/../views/verify_views.php';
    }

    // generate a token and send the account validation email
    public function validateEmail() {
        if (!isset($_SESSION['user_id'])) {
            header("Location: ../views/login_views.php");
            exit;
        }
        $token = $this->token_model->generateToken($_SESSION['user_id'], "validation");
        $this->sendVerificationEmail($_SESSION['email'], $token);
        include __DIR__ . '/../views/verify_views.php';
    }

    // validate the provided token and perform the corresponding action (activate account, reset password, or 2fa login)
    public function tokenForm() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['token'])) {
            $token = $_POST['token'];
            
            // token verification
            $token_data = $this->token_model->verifyToken($token);

            if ($token_data) {
                // Token is valid
                $this->token_model->deleteToken();
                $userId = $token_data['id_user'];

                if ($token_data['types'] === 'validation') {
                    $this->user_model->activateUser($userId);
                    if(isset($_SESSION['user_id'])) {
                         $_SESSION['status'] = 'valide';
                    }
                    header("Location: ../views/images_views.php");
                    exit;

                } elseif ($token_data['types'] === 'reinitialisation') {
                    $_SESSION['user_id'] = $userId; // Connexion temporaire pour le reset
                    header("Location: ../views/reset_password_views.php");
                    exit;

                } elseif ($token_data['types'] === '2FA') {
                    $userFull = $this->user_model->getUserById($userId); 

                    if ($userFull) {
                        $_SESSION['user_id']  = $userFull['id_user'];
                        $_SESSION['username'] = $userFull['username'];
                        $_SESSION['email']    = $userFull['email'];
                        $_SESSION['status']   = $userFull['etat'];
                        $_SESSION['mode']     = '2FA';
                        unset($_SESSION['temp_2fa_user_id']);
                        unset($_SESSION['temp_2fa_email']);
                        header("Location: ../views/images_views.php");
                        exit;
                    } else {
                        $message = "Erreur critique : utilisateur introuvable.";
                        include __DIR__ . '/../views/login_views.php';
                        exit;
                    }
                }
            } else {
                $message = $this->t('token_invalid', "Code invalide ou expiré.");
                include __DIR__ . '/../views/verify_views.php';
            }
        } else {
            include __DIR__ . '/../views/verify_views.php';
        }
    }

    // configure phpmailer with smtp settings from env and send the verification code
    private function sendVerificationEmail($email, $token) {
        try {
            $this->mail->isSMTP();
            $this->mail->Host       = $_ENV['MAILJET_HOST'];
            $this->mail->SMTPAuth   = true;
            $this->mail->Username   = $_ENV['MAILJET_USERNAME'];
            $this->mail->Password   = $_ENV['MAILJET_PASSWORD'];
            $this->mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $this->mail->Port       = $_ENV['MAILJET_PORT'];
            $this->mail->setFrom($_ENV['MAIL_FROM_ADDRESS'], $_ENV['MAIL_FROM_NAME']);
            $this->mail->addAddress($email);
            $this->mail->isHTML(true);
            $this->mail->Subject = $this->t('verification_code_subject', "Verification code");
            $bodyTemplate = $this->t('verification_code_body', "Your verification code is: %TOKEN%");
            if (empty($bodyTemplate)) {
                $bodyTemplate = "Your verification code is: %TOKEN%";
            }
            $body = str_replace('%TOKEN%', $token, $bodyTemplate);
            $this->mail->Body = $body;
            $this->mail->send();
        } catch (Exception $e) {
            echo $this->t('mail_error', "Error sending email: ") . $this->mail->ErrorInfo;
        }
    }

    // enable or disable two-factor authentication mode for the current user
    public function toggle2FA() {
        if (!isset($_SESSION['user_id'])) {
            header("Location: ../views/login_views.php");
            exit;
        }

        $id_user = $_SESSION['user_id'];
        $action = $_POST['mode'] ?? '';
        if ($action === 'enable') {
            $this->user_model->setModeById($id_user, '2FA');
            $_SESSION['mode'] = '2FA';
            $message = $this->t('2fa_enabled', "Two-factor authentication enabled.");
        } elseif ($action === 'disable') {
            $this->user_model->setModeById($id_user, null);
            $_SESSION['mode'] = null;
            $message = $this->t('2fa_disabled', "Two-factor authentication disabled.");
        } else {
            $message = $this->t('invalid_request', "Invalid request.");
        }
        include __DIR__ . '/../views/setting_views.php';
    }

    // destroy the session and redirect to the images view
    public function logout() {
        session_unset();
        session_destroy();
        header("Location: ../views/images_views.php");
        exit;
    }
}

// instantiate controller and handle incoming post/get requests
$controller = new UserController();

// handle post actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['login'])) {
        $controller->login();
    } elseif (isset($_POST['register'])) {
        $controller->register();
    } elseif (isset($_POST['reset_password'])) {
        $controller->resetPasswordForm();
    } elseif (isset($_POST['toggle2FA'])) {
        $controller->toggle2FA();
    }
}

// handle get actions
if (isset($_GET['action'])) {
    switch ($_GET['action']) {
        case 'tokenForm':
            $controller->tokenForm();
            break;
        case 'logout':
            $controller->logout();
            break;
        case 'resetPassword':
            $controller->resetPassword();
            break;
        case 'validateEmail':
            $controller->validateEmail();
            break;
    }
}
?>