<?php
session_start();
require_once __DIR__ . '/../models/images_models.php';

class ImagesController {
    private $images_model;

    public function __construct() {
        // initialize the images model
        $this->images_model = new ImagesModel();
    }

    // upload image and save directly in database
    public function uploadImage() {
        header("content-type: application/json");
        // check if user is logged in and validated
        if (!isset($_SESSION['user_id']) || ($_SESSION['status'] ?? '') !== 'valide') {
            echo json_encode([
                "status" => "error",
                "message" => "you must be logged in and validated to upload an image."
            ]);
            exit;
        }
        // check if a file is uploaded
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['image_input'])) {
            $image = $_FILES['image_input'];
            $allowedTypes = ["image/png", "image/jpeg", "image/webp"];
            // check if file is actually uploaded
            if (!is_uploaded_file($image['tmp_name'])) {
                echo json_encode([
                    "status" => "error",
                    "message" => "invalid file."
                ]);
                return;
            }
            // check real mime type
            $mimeType = mime_content_type($image['tmp_name']);
            if (!in_array($mimeType, $allowedTypes)) {
                echo json_encode([
                    "status" => "error",
                    "message" => "unsupported file type. allowed: jpg, png, webp."
                ]);
                return;
            }
            // check file size (<2mb)
            if ($image['size'] > 2 * 1024 * 1024) {
                echo json_encode([
                    "status" => "error",
                    "message" => "image too large (>2mb)."
                ]);
                return;
            }
            // check image resolution (min 512x512)
            list($w, $h) = getimagesize($image['tmp_name']);
            if ($w < 512 || $h < 512) {
                echo json_encode([
                    "status" => "error",
                    "message" => "image too small (min 512x512)."
                ]);
                return;
            }
            // sanitize and create unique filename
            $originalName = preg_replace("/[^a-z0-9_\.-]/", "_", strtolower(basename($image['name'])));
            $uniqueName = uniqid() . "_" . $originalName;
            // read file content
            $imageData = file_get_contents($image['tmp_name']);
            // save image in database
            $result = $this->images_model->saveImageBlob($uniqueName, $_SESSION['user_id'], $imageData);
            if ($result) {
                echo json_encode([
                    "status" => "success",
                    "file" => $uniqueName,
                    "message" => "image successfully uploaded and stored in database."
                ]);
            } else {
                echo json_encode([
                    "status" => "error",
                    "message" => "database error while saving image."
                ]);
            }
        } else {
            echo json_encode([
                "status" => "error",
                "message" => "no image selected."
            ]);
        }
    }

    public function uploadMosaic() {
        header("content-type: application/json");
        // check if user is logged in and validated
        if (!isset($_SESSION['user_id']) || ($_SESSION['status'] ?? '') !== 'valide') {
            echo json_encode([
                "status" => "error",
                "message" => "you must be logged in and validated to upload a mosaic."
            ]);
            exit;
        }
        // check if mosaic image is set in session
        if (!isset($_SESSION['last_image'])) {
            echo json_encode([
                "status" => "error",
                "message" => "no mosaic image found in session."
            ]);
            return;
        }
        $type = $_POST['choice'] ?? null;
        if (!in_array($type, ['blue', 'red', 'bw'])) {
            echo json_encode([
                "status" => "error",
                "message" => "invalid mosaic type selected."
            ]);
            return;
        }
        // update image type in database
        $result = $this->images_model->setImageType($_SESSION['last_image'], $type);
        if ($result) {
            echo json_encode([
                "status" => "success",
                "message" => "mosaic type successfully updated."
            ]);
        } else {
            echo json_encode([
                "status" => "error",
                "message" => "database error while updating mosaic type."
            ]);
        }
        header("Location: ../views/payment_views.php");
    }

}

// execute controller
$controller = new ImagesController();

// handle post actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['mosaic'])) {
        $controller->uploadMosaic();
    } else {
        $controller->uploadImage();
    }
}