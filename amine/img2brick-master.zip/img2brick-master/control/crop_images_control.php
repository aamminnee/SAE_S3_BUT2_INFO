<?php
session_start();

// disable error reporting to prevent json corruption and set content type
error_reporting(E_ALL & ~E_NOTICE & ~E_WARNING);
ini_set('display_errors', 0);

header("Content-Type: application/json");
require_once __DIR__ . '/../models/images_models.php';

class CropImageController {
    private $model;

    // initialize the images model
    public function __construct() {
        $this->model = new ImagesModel();
    }

    // main logic to handle image cropping, resizing and saving
    public function processCrop() {
        // validate user session and status
        if (!isset($_SESSION['user_id']) || ($_SESSION['status'] ?? '') !== 'valide') {
            echo json_encode(["status"=>"error","message"=>"access denied"]);
            exit;
        }
        $user_id = $_SESSION['user_id'];
        // check if required parameters and file are present
        if (!isset($_FILES['cropped_image']) || !isset($_POST['original_name']) || !isset($_POST['size'])) {
            echo json_encode(["status"=>"error","message"=>"missing parameters"]);
            exit;
        }
        $originalName = basename($_POST['original_name']);
        $cropped = $_FILES['cropped_image'];
        $boardSize = intval($_POST['size']);
        $_SESSION['boardSize'] = $boardSize;
        // if file size is zero, return original name without processing
        if ($cropped['size'] === 0) {
            echo json_encode(["status"=>"success","file"=>$originalName]);
            exit;
        }
        // attempt to create image resource from uploaded file
        $source = @imagecreatefrompng($cropped['tmp_name']);
        if (!$source) {
            echo json_encode(["status"=>"error","message"=>"invalid image data"]);
            exit;
        }
        $width = imagesx($source);
        $height = imagesy($source);
        // create truecolor image and handle transparency
        $resized = imagecreatetruecolor($boardSize, $boardSize);
        imagealphablending($resized, false);
        imagesavealpha($resized, true);
        $transparent = imagecolorallocatealpha($resized, 0, 0, 0, 127);
        imagefilledrectangle($resized, 0, 0, $boardSize, $boardSize, $transparent);
        imagecopyresampled($resized, $source, 0, 0, 0, 0, $boardSize, $boardSize, $width, $height);
        // capture image binary data using output buffering
        ob_start();
        imagepng($resized);
        $imageData = ob_get_clean();
        $newName = uniqid('img_crop_', true) . '.png';
        // update the image blob in the database
        $updateResult = $this->model->updateImageBlob($originalName, $newName, $user_id, $imageData);
        imagedestroy($source);
        imagedestroy($resized);
        // return result as json
        if ($updateResult) {
            echo json_encode(["status"=>"success","file"=>$newName]);
        } else {
            echo json_encode(["status"=>"error","message"=>"error updating image in database"]);
        }
        exit;
    }
}

$controller = new CropImageController();
$controller->processCrop();