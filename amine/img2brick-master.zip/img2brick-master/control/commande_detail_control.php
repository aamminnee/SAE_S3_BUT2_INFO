<?php
session_start();
require_once __DIR__ . '/../models/commande_models.php';
require_once __DIR__ . '/../models/images_models.php';

$commandeModel = new CommandeModel();
$imagesModel = new ImagesModel(); 
// get the id from the url parameters or default to 0
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
// retrieve the command by id
$commande = $commandeModel->getCommandeById($id);
// check if the command exists
if (!$commande) {
    // stop execution if command is not found
    die("Erreur : Commande introuvable.");
}
// retrieve the image associated with the command
$mosaic = $imagesModel->getImageById($commande['id_images']);
include __DIR__ . '/../views/header.php';
// initialize translation array with fallback
$tr = $t ?? [];
include __DIR__ . '/../views/commande_detail_views.php';
?>