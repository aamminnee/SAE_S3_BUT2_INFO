<?php


// prevent multiple loading of the configuration file
if (defined('CONFIG_LOADED')) {
    return;
}
define('CONFIG_LOADED', true);

require_once __DIR__ . '/../vendor/autoload.php';

use Dotenv\Dotenv;

// load environment variables using dotenv
$dotenv = Dotenv::createImmutable(__DIR__ . '/../');
$dotenv->safeLoad();

$BASE_URL = $_ENV['BASE_URL'];

?>