<?php
session_start();
require_once __DIR__ . '/../models/images_models.php';
// check user authentication and status permissions
if (!isset($_SESSION['user_id']) || ($_SESSION['status'] ?? '') !== 'valide') {
    http_response_code(403);
    exit('access denied');
}
// validate that the image parameter is present in the url
if (!isset($_GET['img'])) {
    http_response_code(400);
    exit('missing image');
}
$user_id = $_SESSION['user_id'];
$image_name = $_GET['img'];
$model = new ImagesModel();
// retrieve the latest image blob from the database for the specific user
$row = $model->getLastImageBlobByUser($user_id, $image_name);
if (!$row) {
    http_response_code(404);
    exit('image not found');
}
// set content header and output the binary image data
header('Content-Type: image/png'); // or jpeg/webp if needed
echo $row['image'];