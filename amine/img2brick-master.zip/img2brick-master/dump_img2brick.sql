-- phpMyAdmin SQL Dump
-- version 5.2.3
-- https://www.phpmyadmin.net/
--
-- Host: mysql-aissyne.alwaysdata.net
-- Generation Time: Dec 21, 2025 at 01:19 PM
-- Server version: 10.11.14-MariaDB
-- PHP Version: 8.4.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `aissyne_img2brick`
--

-- --------------------------------------------------------

--
-- Table structure for table `commande`
--

CREATE TABLE `commande` (
  `id_commande` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `id_images` int(11) NOT NULL,
  `id_cord` int(11) NOT NULL,
  `adresse` varchar(255) NOT NULL,
  `code_postal` varchar(10) NOT NULL,
  `ville` varchar(100) NOT NULL,
  `pays` varchar(100) NOT NULL,
  `telephone` varchar(20) NOT NULL,
  `montant` decimal(10,2) NOT NULL,
  `date_commande` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `commande`
--

INSERT INTO `commande` (`id_commande`, `id_user`, `id_images`, `id_cord`, `adresse`, `code_postal`, `ville`, `pays`, `telephone`, `montant`, `date_commande`) VALUES
(77, 25, 110, 89, '2 rue Albert Einstein', '77420', 'Champs sur Marne', 'France', '0160957500', 12.99, '2025-12-21 13:17:18');

-- --------------------------------------------------------

--
-- Table structure for table `cord_banquaire`
--

CREATE TABLE `cord_banquaire` (
  `id_cord` int(11) NOT NULL,
  `card_number` varchar(255) NOT NULL,
  `expiry` varchar(10) NOT NULL,
  `cvc` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cord_banquaire`
--

INSERT INTO `cord_banquaire` (`id_cord`, `card_number`, `expiry`, `cvc`) VALUES
(89, '$2y$10$R5hTykS.vD1kXIMTYw0oSu7vRPJzgSTqLcbeCtjTOey1.q4LZ9bR.', '12/34', '$2y$10$bSD0XDyUImrrGHhOMmqO/.QVtD6has2u0lLwIahlFNX.cAGJl7fA6');

-- --------------------------------------------------------

--
-- Table structure for table `images`
--

CREATE TABLE `images` (
  `id` int(11) NOT NULL,
  `identifiant` varchar(255) NOT NULL,
  `id_user` int(11) NOT NULL,
  `type` varchar(255) DEFAULT NULL,
  `image` longblob DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `images`
--

INSERT INTO `images` (`id`, `identifiant`, `id_user`, `type`, `image`) VALUES
(110, 'img_crop_6947e4a3f1c604.96002156.png', 25, 'blue', 0x89504e470d0a1a0a0000000d4948445200000040000000400806000000aa6971de000000097048597300000ec400000ec401952b0e1b000003f349444154789ced9bdf6e1b4514c67f333bdeb51dd42424e04a883688228178042e7883f6860b2e78055e0871d10b6e106fc01ddc2155d088503554216a4522db49d3386efc6777bd870bfff7ee3a35b17652793fc9f2f199b373befd76ce8e353bab7efaf657510008006af00d8292143f804cfbe7b7cfc4c82066d19c08488a3fe5d8ab729acdf2f654476a9024d6792ac1093b466ed026298463c46648a68938c32f49c0c43e65561841b304a8657492694219594b11e0edc358c1a50820d76c5f7ac2053ac8a404965e22d7ee301f0123cb54be284dfc1ede21e359542cebf0ae7a55ec649fe3e3de387664cacc854fe73abef30f9be69c57b55a5dfa057a9bb0a2b3c018b900b609d8462e806d02b6611a8d866d0e56613a9d8e6d0e56b1f225900b609b806de402d826601bb9005925faebcf5d1efdfe38e6dfdfdfcf8a42224c56891e7eff1dda2b1146c2eb6613570544bac8df4f9f70523be6d6c616676767388ec3e9cb57dc7f701f2783d5d6cc0410e9715cadf3e30f0f69b6034a4517476b0a8e62eff1235aed2e8ee751743ddefbe0231e64c42bb3125028d6d6d62897cb74fd90823118e3a094a217fa6cbf5fa15eaba1803b7777d019adb5abdddddd4c56845a979768c750f45c8230240802ce4fabfcfccb6f7cf3f55738a640b7db268a04c7183cd7cd82567602dc54e4d3a06d02b6910bb0f20b22ebeb1bb6395885aa9e47f92cb0ca5879018cdf796d9b83559857b543db1cac421f1c1cf0efd131ddae6f9b8b15e893933aadf6ea3e1b50cffe395ae96930ff1fd00d7ab6395885f60a8e6d0e5661ce4f9edbe66015a6dbbab0cdc12a1257857bbe22b8189486ccdbca36ed5753ae2be286fec4ad7692b8556e7217fafcb8f8f6ba68dd43ca0566912840e399c7c5935b288950a31de4433b4249dfa7927c44a3a4b3febe3df691d68ecc899d699fe2d1b789b50b9dcf36f1bfbcfb6602486c629444731114b78a94b65ca413105c86184fe114140a41173484211209c6d3744f5bf8f5cbe4fc574048d9491b3f2920edc1482c562d44220961a7877fe123dd104488424dd40e500e68d3174021446da1d70aae956b11240aa0bd100a3e8820a3b731fac3b05fb7437f3450b6ff91a99219c70b82ef87042fc7439258e94c0c5f04e5ca445f0c4aaaff4244df66c2af06fefef557313f84e5e4e93e5180f57b3e6b3bf5ffad6a1c8a172f5c9a4dcde6bb3d9a0d87caed907647a101e30a4643b5ea10f414dbdb3d6e57c289f744ae0f634ce2e247f208d01a77c94f664e6b2576f75c3efddc67ef0f8f9d8f030e0f0b6c6d44445a78c783e7470e0523dcfb24e0ce87ada5e64f83b52743510ff40df8136a6d49ec269c3ce46b82b9002b2f80a9542ab63958c5ca8f805c00db046c2317c03601dbf80f0d8505ab7874ceaf0000000049454e44ae426082);

-- --------------------------------------------------------

--
-- Table structure for table `tokens`
--

CREATE TABLE `tokens` (
  `id_token` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `token` varchar(10) NOT NULL,
  `types` varchar(50) NOT NULL,
  `expires_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `translations`
--

CREATE TABLE `translations` (
  `id` int(11) NOT NULL,
  `key_name` varchar(100) NOT NULL,
  `lang` varchar(5) NOT NULL,
  `texte` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `translations`
--

INSERT INTO `translations` (`id`, `key_name`, `lang`, `texte`) VALUES
(107, 'account_title', 'fr', 'Mon compte'),
(108, 'account_title', 'en', 'My Account'),
(109, 'back', 'fr', 'Retour'),
(110, 'back', 'en', 'Back'),
(111, 'account_images', 'fr', 'Vos images'),
(112, 'account_images', 'en', 'Your Images'),
(113, 'no_images', 'fr', 'Aucune image téléchargée pour le moment.'),
(114, 'no_images', 'en', 'No images uploaded yet.'),
(115, 'view_more_images', 'fr', 'Voir plus'),
(116, 'view_more_images', 'en', 'View More'),
(117, 'account_info', 'fr', 'Informations du compte'),
(118, 'account_info', 'en', 'Account Information'),
(119, 'username', 'fr', 'Nom d’utilisateur'),
(120, 'username', 'en', 'Username'),
(121, 'email', 'fr', 'Email'),
(122, 'email', 'en', 'Email'),
(123, 'status', 'fr', 'Statut'),
(124, 'status', 'en', 'Status'),
(125, 'mode_label', 'fr', 'Mode'),
(126, 'mode_label', 'en', 'Mode'),
(127, 'valide_email', 'fr', 'Valider l’email'),
(128, 'valide_email', 'en', 'Validate Email'),
(129, 'reset_password', 'fr', 'Réinitialiser le mot de passe'),
(130, 'reset_password', 'en', 'Reset Password'),
(131, 'two_factor_auth', 'fr', 'Authentification à deux facteurs'),
(132, 'two_factor_auth', 'en', 'Two-Factor Authentication'),
(133, 'disable_2fa', 'fr', 'Désactiver la double authentification'),
(134, 'disable_2fa', 'en', 'Disable 2FA'),
(135, 'enable_2fa', 'fr', 'Activer la double authentification'),
(136, 'enable_2fa', 'en', 'Enable 2FA'),
(137, '2fa_enabled', 'fr', 'L’authentification à deux facteurs est activée.'),
(138, '2fa_enabled', 'en', 'Two-factor authentication is enabled.'),
(139, '2fa_disabled', 'fr', 'L’authentification à deux facteurs est désactivée.'),
(140, '2fa_disabled', 'en', 'Two-factor authentication is disabled.'),
(141, 'order_confirmation', 'fr', 'Confirmation de commande'),
(142, 'order_confirmation', 'en', 'Order Confirmation'),
(143, 'thank_you_order', 'fr', 'Merci pour votre commande !'),
(144, 'thank_you_order', 'en', 'Thank you for your order!'),
(145, 'order_processing', 'fr', 'Votre mosaïque est en cours de préparation.<br>Vous recevrez un email de confirmation sous peu.'),
(146, 'order_processing', 'en', 'Your mosaic is being prepared.<br>You will receive a confirmation email shortly.'),
(147, 'chosen_mosaic', 'fr', 'Mosaïque choisie'),
(148, 'chosen_mosaic', 'en', 'Chosen Mosaic'),
(149, 'order_number', 'fr', 'Numéro de commande :'),
(150, 'order_number', 'en', 'Order Number:'),
(151, 'amount_paid', 'fr', 'Montant payé :'),
(152, 'amount_paid', 'en', 'Amount Paid:'),
(153, 'shipping_address', 'fr', 'Adresse de livraison :'),
(154, 'shipping_address', 'en', 'Shipping Address:'),
(155, 'return_home', 'fr', 'Retour à l\'accueil'),
(156, 'return_home', 'en', 'Return to Home'),
(157, 'no_order_error', 'fr', 'Erreur : aucune commande trouvée.'),
(158, 'no_order_error', 'en', 'Error: no order found.'),
(159, 'access_denied', 'fr', 'Accès refusé.'),
(160, 'access_denied', 'en', 'Access denied.'),
(161, 'no_image_selected', 'fr', 'Aucune image sélectionnée.'),
(162, 'no_image_selected', 'en', 'No image selected.'),
(163, 'image_not_found', 'fr', 'Image introuvable.'),
(164, 'image_not_found', 'en', 'Image not found.'),
(165, 'crop_preview_title', 'fr', 'Prévisualisation et Recadrage'),
(166, 'crop_preview_title', 'en', 'Crop and Preview'),
(167, 'crop_your_image', 'fr', 'Recadrez votre image'),
(168, 'crop_your_image', 'en', 'Crop your image'),
(169, 'image_to_crop', 'fr', 'Image à recadrer'),
(170, 'image_to_crop', 'en', 'Image to crop'),
(171, 'apply_continue', 'fr', 'Appliquer et Continuer'),
(172, 'apply_continue', 'en', 'Apply and Continue'),
(173, 'render_options', 'fr', 'Options de rendu'),
(174, 'render_options', 'en', 'Render Options'),
(175, 'board_size', 'fr', 'Taille du tableau :'),
(176, 'board_size', 'en', 'Board size:'),
(177, 'size_32', 'fr', '32 x 32 tenons'),
(178, 'size_32', 'en', '32 x 32 studs'),
(179, 'size_64', 'fr', '64 x 64 tenons'),
(180, 'size_64', 'en', '64 x 64 studs'),
(181, 'size_96', 'fr', '96 x 96 tenons'),
(182, 'size_96', 'en', '96 x 96 studs'),
(183, 'crop_ratio', 'fr', 'Ratio de recadrage :'),
(184, 'crop_ratio', 'en', 'Crop ratio:'),
(185, 'ratio_free', 'fr', 'Libre'),
(186, 'ratio_free', 'en', 'Free'),
(187, 'ratio_square', 'fr', 'Carré (1:1)'),
(188, 'ratio_square', 'en', 'Square (1:1)'),
(189, 'ratio_43', 'fr', '4:3'),
(190, 'ratio_43', 'en', '4:3'),
(191, 'ratio_169', 'fr', '16:9'),
(192, 'ratio_169', 'en', '16:9'),
(193, 'home', 'en', 'Home'),
(194, 'my_account', 'en', 'My Account'),
(195, 'setting_title', 'en', 'Settings'),
(196, 'logged_in_as', 'en', 'Logged in as'),
(197, 'logout', 'en', 'Logout'),
(198, 'login', 'en', 'Login'),
(199, 'register', 'en', 'Register'),
(200, 'home', 'fr', 'Accueil'),
(201, 'my_account', 'fr', 'Mon compte'),
(202, 'setting_title', 'fr', 'Paramètres'),
(203, 'logged_in_as', 'fr', 'Connecté en tant que'),
(204, 'logout', 'fr', 'Déconnexion'),
(205, 'login', 'fr', 'Connexion'),
(206, 'register', 'fr', 'Inscription'),
(207, 'upload_title', 'en', 'img2brick - Upload Image'),
(208, 'upload_subtitle', 'en', 'Turn your images into brick mosaics!'),
(209, 'drop_instructions', 'en', 'Drag & drop your image here, paste it with <strong>Ctrl + V</strong>, or use the button below.'),
(210, 'choose_file', 'en', 'Choose a file'),
(211, 'continue', 'en', 'Continue'),
(212, 'upload_title', 'fr', 'img2brick - Dépose d\'image'),
(213, 'upload_subtitle', 'fr', 'Transformez vos images en tableaux de briques !'),
(214, 'drop_instructions', 'fr', 'Glissez-déposez votre image ici, collez-la avec <strong>Ctrl + V</strong>, ou utilisez le bouton ci-dessous.'),
(215, 'choose_file', 'fr', 'Choisir un fichier'),
(216, 'continue', 'fr', 'Continuer'),
(217, 'login_title', 'en', 'User Login'),
(218, 'login_header', 'en', 'Login'),
(219, 'username_label', 'en', 'Username'),
(220, 'password_label', 'en', 'Password'),
(221, 'login_button', 'en', 'Login'),
(222, 'login_title', 'fr', 'Connexion Utilisateur'),
(223, 'login_header', 'fr', 'Connexion'),
(224, 'username_label', 'fr', 'Nom d\'utilisateur'),
(225, 'password_label', 'fr', 'Mot de passe'),
(226, 'login_button', 'fr', 'Connexion'),
(227, 'checkout_title', 'en', 'Finalize my order'),
(228, 'selected_mosaic', 'en', 'Selected mosaic'),
(229, 'estimated_price', 'en', 'Estimated price'),
(230, 'shipping_info', 'en', 'Shipping Information'),
(231, 'address', 'en', 'Address'),
(232, 'postal_code', 'en', 'Postal Code'),
(233, 'city', 'en', 'City'),
(234, 'country', 'en', 'Country'),
(235, 'phone', 'en', 'Phone'),
(236, 'payment', 'en', 'Payment'),
(237, 'confirm_order', 'en', 'Confirm Order'),
(238, 'access_denied', 'en', 'Access denied'),
(239, 'no_mosaic_selected', 'en', 'No mosaic selected'),
(240, 'checkout_title', 'fr', 'Finaliser ma commande'),
(241, 'selected_mosaic', 'fr', 'Mosaïque sélectionnée'),
(242, 'estimated_price', 'fr', 'Prix estimé'),
(243, 'shipping_info', 'fr', 'Informations de livraison'),
(244, 'address', 'fr', 'Adresse'),
(245, 'postal_code', 'fr', 'Code postal'),
(246, 'city', 'fr', 'Ville'),
(247, 'country', 'fr', 'Pays'),
(248, 'phone', 'fr', 'Téléphone'),
(249, 'payment', 'fr', 'Paiement'),
(250, 'confirm_order', 'fr', 'Confirmer ma commande'),
(251, 'access_denied', 'fr', 'Accès refusé'),
(252, 'no_mosaic_selected', 'fr', 'Aucune mosaïque sélectionnée'),
(253, 'register_title', 'en', 'User Registration'),
(254, 'register_header', 'en', 'Register'),
(255, 'username_label', 'en', 'Username'),
(256, 'email_label', 'en', 'Email'),
(257, 'password_label', 'en', 'Password'),
(258, 'register_button', 'en', 'Register'),
(259, 'register_title', 'fr', 'Inscription Utilisateur'),
(260, 'register_header', 'fr', 'Inscription'),
(261, 'username_label', 'fr', 'Nom d\'utilisateur'),
(262, 'email_label', 'fr', 'Email'),
(263, 'password_label', 'fr', 'Mot de passe'),
(264, 'register_button', 'fr', 'S\'inscrire'),
(265, 'reset_password_title', 'en', 'Reset your password'),
(266, 'reset_password_header', 'en', 'Reset Password'),
(267, 'new_password_label', 'en', 'New password'),
(268, 'confirm_password_label', 'en', 'Confirm password'),
(269, 'reset_password_button', 'en', 'Reset'),
(270, 'reset_password_title', 'fr', 'Réinitialiser votre mot de passe'),
(271, 'reset_password_header', 'fr', 'Réinitialiser le mot de passe'),
(272, 'new_password_label', 'fr', 'Nouveau mot de passe'),
(273, 'confirm_password_label', 'fr', 'Confirmer le mot de passe'),
(274, 'reset_password_button', 'fr', 'Réinitialiser'),
(275, 'access_denied', 'en', 'access denied'),
(276, 'image_not_found', 'en', 'image not found'),
(277, 'review_mosaics_title', 'en', 'Your generated mosaics'),
(278, 'blue_version', 'en', 'Blue version'),
(279, 'red_version', 'en', 'Red version'),
(280, 'bw_version', 'en', 'Black & White'),
(281, 'select', 'en', 'Select'),
(282, 'confirm_choice', 'en', 'Confirm my choice'),
(283, 'access_denied', 'fr', 'accès refusé'),
(284, 'image_not_found', 'fr', 'image introuvable'),
(285, 'review_mosaics_title', 'fr', 'Voici vos mosaïques générées'),
(286, 'blue_version', 'fr', 'Version bleue'),
(287, 'red_version', 'fr', 'Version rouge'),
(288, 'bw_version', 'fr', 'Noir et blanc'),
(289, 'select', 'fr', 'Sélectionner'),
(290, 'confirm_choice', 'fr', 'Valider mon choix'),
(291, 'setting_title', 'en', 'Settings'),
(292, 'back', 'en', 'Back'),
(293, 'language', 'en', 'Language'),
(294, 'french', 'en', 'French'),
(295, 'english', 'en', 'English'),
(296, 'theme', 'en', 'Theme'),
(297, 'light', 'en', 'Light'),
(298, 'dark', 'en', 'Dark'),
(299, 'account', 'en', 'Account'),
(300, 'my_account', 'en', 'My Account'),
(301, 'setting_title', 'fr', 'Paramètres'),
(302, 'back', 'fr', 'Retour'),
(303, 'language', 'fr', 'Langue'),
(304, 'french', 'fr', 'Français'),
(305, 'english', 'fr', 'Anglais'),
(306, 'theme', 'fr', 'Thème'),
(307, 'light', 'fr', 'Clair'),
(308, 'dark', 'fr', 'Sombre'),
(309, 'account', 'fr', 'Compte'),
(310, 'my_account', 'fr', 'Mon Compte'),
(311, 'verify_title', 'en', 'Account Verification'),
(312, 'verify_header', 'en', 'Enter your verification code'),
(313, 'verify_placeholder', 'en', '6 digits'),
(314, 'verify_button', 'en', 'Validate'),
(315, 'login_link_text', 'en', 'Go to Login'),
(316, 'verify_title', 'fr', 'Vérification du compte'),
(317, 'verify_header', 'fr', 'Entrez votre code de vérification'),
(318, 'verify_placeholder', 'fr', '6 chiffres'),
(319, 'verify_button', 'fr', 'Valider'),
(320, 'login_link_text', 'fr', 'Aller à la connexion'),
(321, 'large_image_warning', 'en', 'The image is very large. It may be resized for better performance.'),
(322, 'no_crop_applied', 'en', 'No crop applied, original image kept.'),
(323, 'crop_success', 'en', 'Image successfully cropped!'),
(324, 'error_prefix', 'en', 'Error: '),
(325, 'processing', 'en', 'Processing...'),
(326, 'large_image_warning', 'fr', 'L\'image est très grande. Elle peut être redimensionnée pour de meilleures performances.'),
(327, 'no_crop_applied', 'fr', 'Aucun recadrage appliqué, image originale conservée.'),
(328, 'crop_success', 'fr', 'Image recadrée avec succès !'),
(329, 'error_prefix', 'fr', 'Erreur : '),
(330, 'processing', 'fr', 'Traitement en cours...'),
(331, 'en', 'no_fi', 'No image selected.'),
(332, 'fr', 'no_fi', 'Aucune image sélectionnée.'),
(333, 'en', 'login', 'You must be logged in and validated to upload an image.'),
(334, 'fr', 'login', 'Vous devez être connecté et validé pour déposer une image.'),
(335, 'en', 'unsup', 'Unsupported file type. Allowed: JPG, PNG, WEBP.'),
(336, 'fr', 'unsup', 'Type de fichier non supporté. Formats : JPG, PNG, WEBP.'),
(337, 'en', 'file_', 'Image too large (>2MB).'),
(338, 'fr', 'file_', 'Image trop volumineuse (>2 Mo).'),
(339, 'en', 'file_', 'Image too small (min 512x512).'),
(340, 'fr', 'file_', 'Image trop petite (min 512x512).'),
(341, 'en', 'file_', 'Image successfully loaded, click Continue.'),
(342, 'fr', 'file_', 'Image bien importée, cliquez sur Continuer.'),
(343, 'en', 'uploa', 'Uploading...'),
(344, 'fr', 'uploa', 'Téléversement en cours...'),
(345, 'en', 'error', 'Error:'),
(346, 'fr', 'error', 'Erreur :'),
(347, 'no_file_selected', 'en', 'No image selected.'),
(348, 'no_file_selected', 'fr', 'Aucune image sélectionnée.'),
(349, 'login_required', 'en', 'You must be logged in and validated to upload an image.'),
(350, 'login_required', 'fr', 'Vous devez être connecté et validé pour déposer une image.'),
(351, 'unsupported_type', 'en', 'Unsupported file type. Allowed: JPG, PNG, WEBP.'),
(352, 'unsupported_type', 'fr', 'Type de fichier non supporté. Formats : JPG, PNG, WEBP.'),
(353, 'file_too_large', 'en', 'Image too large (>2MB).'),
(354, 'file_too_large', 'fr', 'Image trop volumineuse (>2 Mo).'),
(355, 'file_too_small', 'en', 'Image too small (min 512x512).'),
(356, 'file_too_small', 'fr', 'Image trop petite (min 512x512).'),
(357, 'file_ok', 'en', 'Image successfully loaded, click Continue.'),
(358, 'file_ok', 'fr', 'Image bien importée, cliquez sur Continuer.'),
(359, 'uploading', 'en', 'Uploading...'),
(360, 'uploading', 'fr', 'Téléversement en cours...'),
(361, 'error_prefix', 'en', 'Error:'),
(362, 'error_prefix', 'fr', 'Erreur :'),
(363, 'access_denied', 'en', 'Access denied.'),
(364, 'access_denied', 'fr', 'Accès refusé.'),
(365, 'missing_parameters', 'en', 'Missing parameters.'),
(366, 'missing_parameters', 'fr', 'Paramètres manquants.'),
(367, 'crop_save_error', 'en', 'Error saving cropped image.'),
(368, 'crop_save_error', 'fr', 'Erreur lors de l\'enregistrement du recadrage.'),
(369, 'db_update_error', 'en', 'Error updating database.'),
(370, 'db_update_error', 'fr', 'Erreur lors de la mise à jour en base de données.'),
(371, 'login_required', 'en', 'You must be logged in and validated to upload an image.'),
(372, 'login_required', 'fr', 'Vous devez être connecté et validé pour déposer une image.'),
(373, 'unsupported_type', 'en', 'Unsupported file type. Allowed: JPG, PNG, WEBP.'),
(374, 'unsupported_type', 'fr', 'Type de fichier non supporté. Formats : JPG, PNG, WEBP.'),
(375, 'invalid_file', 'en', 'Invalid file.'),
(376, 'invalid_file', 'fr', 'Fichier invalide.'),
(377, 'file_too_large', 'en', 'Image too large (>2MB).'),
(378, 'file_too_large', 'fr', 'Fichier trop volumineux (>2 Mo).'),
(379, 'file_too_small', 'en', 'Image too small (min 512x512).'),
(380, 'file_too_small', 'fr', 'Résolution minimale : 512x512 pixels.'),
(381, 'file_ok', 'en', 'Image successfully loaded, click Continue.'),
(382, 'file_ok', 'fr', 'Image bien importée, cliquez sur Continuer.'),
(383, 'upload_error', 'en', 'Error during upload.'),
(384, 'upload_error', 'fr', 'Erreur lors de l\'upload.'),
(385, 'no_file_selected', 'en', 'No image selected.'),
(386, 'no_file_selected', 'fr', 'Aucune image sélectionnée.'),
(387, 'no_action_detected', 'en', 'No action detected.'),
(388, 'no_action_detected', 'fr', 'Aucune action détectée.'),
(389, 'access_denied', 'en', 'Access denied.'),
(390, 'access_denied', 'fr', 'Accès refusé.'),
(391, 'image_not_found', 'en', 'Error: image not found in session.'),
(392, 'image_not_found', 'fr', 'Erreur : image non trouvée dans la session.'),
(393, 'mosaic_creation_error', 'en', 'Error while creating mosaic file.'),
(394, 'mosaic_creation_error', 'fr', 'Erreur lors de la création du fichier mosaïque.'),
(395, 'db_save_error', 'en', 'An error occurred while saving in database.'),
(396, 'db_save_error', 'fr', 'Une erreur est survenue lors de la sauvegarde en base.'),
(397, 'no_selection_received', 'en', 'No selection received.'),
(398, 'no_selection_received', 'fr', 'Aucune sélection reçue.'),
(399, 'no_action_detected', 'en', 'No action detected.'),
(400, 'no_action_detected', 'fr', 'Aucune action détectée.'),
(401, 'access_denied', 'en', 'Access denied.'),
(402, 'access_denied', 'fr', 'Accès refusé.'),
(403, 'no_mosaic_selected', 'en', 'No mosaic selected.'),
(404, 'no_mosaic_selected', 'fr', 'Aucune mosaïque sélectionnée.'),
(405, 'bank_info_error', 'en', 'Error while saving bank details.'),
(406, 'bank_info_error', 'fr', 'Erreur lors de l\'enregistrement des coordonnées bancaires.'),
(407, 'order_save_error', 'en', 'Error while saving order.'),
(408, 'order_save_error', 'fr', 'Erreur lors de l\'enregistrement de la commande.'),
(409, 'no_action_detected', 'en', 'No action detected.'),
(410, 'no_action_detected', 'fr', 'Aucune action détectée.'),
(411, 'setting_title', 'en', 'Settings'),
(412, 'setting_title', 'fr', 'Paramètres'),
(413, 'back', 'en', 'back'),
(414, 'back', 'fr', 'retour'),
(415, 'language', 'en', 'Language'),
(416, 'language', 'fr', 'Langue'),
(417, 'theme', 'en', 'Theme'),
(418, 'theme', 'fr', 'Thème'),
(419, 'light', 'en', 'Light'),
(420, 'light', 'fr', 'Clair'),
(421, 'dark', 'en', 'Dark'),
(422, 'dark', 'fr', 'Sombre'),
(423, 'account', 'en', 'Account'),
(424, 'account', 'fr', 'Compte'),
(425, 'my_account', 'en', 'My Account'),
(426, 'my_account', 'fr', 'Mon Compte'),
(427, 'login_error', 'en', 'Incorrect username or password.'),
(428, 'login_error', 'fr', 'Nom d\'utilisateur ou mot de passe incorrect.'),
(429, 'register_error', 'en', 'Registration failed, please try again.'),
(430, 'register_error', 'fr', 'Échec de l\'inscription, veuillez réessayer.'),
(431, 'password_reset_success', 'en', 'Password reset successfully.'),
(432, 'password_reset_success', 'fr', 'Mot de passe réinitialisé avec succès.'),
(433, 'password_mismatch', 'en', 'Passwords do not match.'),
(434, 'password_mismatch', 'fr', 'Les mots de passe ne correspondent pas.'),
(435, 'token_invalid', 'en', 'Invalid or expired code.'),
(436, 'token_invalid', 'fr', 'Code invalide ou expiré.'),
(437, 'verification_code_subject', 'en', 'Verification code'),
(438, 'verification_code_subject', 'fr', 'Code de verification'),
(439, 'verification_code_body', 'en', 'Your verification code is: <b>%TOKEN%</b>'),
(440, 'verification_code_body', 'fr', 'Votre code de vérification est : <b>%TOKEN%</b>'),
(441, 'mail_error', 'en', 'Error sending email: '),
(442, 'mail_error', 'fr', 'Erreur lors de l\'envoi du mail : '),
(443, '2fa_enabled', 'en', 'Two-factor authentication enabled.'),
(444, '2fa_enabled', 'fr', 'Authentification à deux facteurs activée.'),
(445, '2fa_disabled', 'en', 'Two-factor authentication disabled.'),
(446, '2fa_disabled', 'fr', 'Authentification à deux facteurs désactivée.'),
(447, 'invalid_request', 'en', 'Invalid request.'),
(448, 'invalid_request', 'fr', 'Requête invalide.'),
(449, 'captcha_label', 'fr', 'Veuillez entrer le texte affiché'),
(450, 'captcha_label', 'en', 'Please enter the text shown'),
(451, 'captcha_placeholder', 'fr', 'Entrez le code captcha'),
(452, 'captcha_placeholder', 'en', 'Enter the captcha code'),
(453, 'captcha_reload', 'fr', 'Recharger le captcha'),
(454, 'captcha_reload', 'en', 'Reload captcha'),
(455, 'captcha_required', 'fr', 'Le captcha est requis.'),
(456, 'captcha_required', 'en', 'Captcha is required.'),
(457, 'captcha_incorrect', 'fr', 'Le captcha est incorrect, veuillez réessayer.'),
(458, 'captcha_incorrect', 'en', 'Incorrect captcha, please try again.'),
(459, 'captcha_success', 'fr', 'Captcha validé avec succès.'),
(460, 'captcha_success', 'en', 'Captcha successfully validated.'),
(461, 'login_button', 'fr', 'Se connecter'),
(462, 'login_button', 'en', 'Login'),
(463, 'username_label', 'fr', 'Nom d\'utilisateur'),
(464, 'username_label', 'en', 'Username'),
(465, 'password_label', 'fr', 'Mot de passe'),
(466, 'password_label', 'en', 'Password'),
(467, 'captcha_instruction', 'fr', 'Tapez le texte affiché dans l’image ci-dessous pour confirmer que vous êtes humain.'),
(468, 'captcha_instruction', 'en', 'Type the text shown in the image below to confirm you are human.'),
(469, 'captcha_label', 'fr', 'Veuillez entrer le texte affiché'),
(470, 'captcha_label', 'en', 'Please enter the text shown'),
(471, 'captcha_placeholder', 'fr', 'Entrez le code captcha'),
(472, 'captcha_placeholder', 'en', 'Enter the captcha code'),
(473, 'captcha_reload', 'fr', 'Recharger le captcha'),
(474, 'captcha_reload', 'en', 'Reload captcha'),
(475, 'captcha_required', 'fr', 'Le captcha est requis.'),
(476, 'captcha_required', 'en', 'Captcha is required.'),
(477, 'captcha_invalid', 'fr', 'Le captcha est incorrect, veuillez réessayer.'),
(478, 'captcha_invalid', 'en', 'Incorrect captcha. Please try again.'),
(479, 'captcha_success', 'fr', 'Captcha validé avec succès.'),
(480, 'captcha_success', 'en', 'Captcha successfully validated.'),
(481, 'login_button', 'fr', 'Se connecter'),
(482, 'login_button', 'en', 'Login'),
(483, 'username_label', 'fr', 'Nom d\'utilisateur'),
(484, 'username_label', 'en', 'Username'),
(485, 'password_label', 'fr', 'Mot de passe'),
(486, 'password_label', 'en', 'Password'),
(487, 'refresh', 'fr', 'Rafraichir'),
(488, 'refresh', 'en', 'Refresh'),
(489, 'captcha_info', 'fr', 'Tapez le texte affiché dans l’image ci-dessous pour confirmer que vous êtes humain.'),
(490, 'captcha_info', 'en', 'Type the text shown in the image below to confirm you are human.'),
(491, 'register_link', 'fr', 'Pas encore de compte ? Créez-en un ici.'),
(492, 'register_link', 'en', 'Don\'t have an account yet? Create one here.'),
(493, 'login_link', 'fr', 'Déjà inscrit ? Connectez-vous ici.'),
(494, 'login_link', 'en', 'Already have an account? Log in here.'),
(495, 'payment_info', 'fr', 'Mode de paiement simulé dans le cadre du projet (aucun paiement réel) '),
(496, 'payment_info', 'en', 'Simulated payment method as part of the project (no real payment)'),
(497, 'orders_title', 'fr', 'Mes commandes'),
(498, 'orders_title', 'en', 'My Orders'),
(499, 'orders_intro', 'fr', 'Retrouvez ici toutes vos commandes précédentes. Cliquez sur une commande pour en voir les détails.'),
(500, 'orders_intro', 'en', 'Find all your past orders here. Click an order to view details.'),
(501, 'new_order', 'fr', 'Nouvelle commande'),
(502, 'new_order', 'en', 'New Order'),
(503, 'no_orders', 'fr', 'Aucune commande trouvée.'),
(504, 'no_orders', 'en', 'No orders found.'),
(505, 'order_number', 'fr', 'Numéro de commande'),
(506, 'order_number', 'en', 'Order number'),
(507, 'date', 'fr', 'Date'),
(508, 'date', 'en', 'Date'),
(509, 'status', 'fr', 'Statut'),
(510, 'status', 'en', 'Status'),
(511, 'mosaic', 'fr', 'Mosaïque'),
(512, 'mosaic', 'en', 'Mosaic'),
(513, 'amount', 'fr', 'Montant'),
(514, 'amount', 'en', 'Amount'),
(515, 'actions', 'fr', 'Actions'),
(516, 'actions', 'en', 'Actions'),
(517, 'view_details', 'fr', 'Voir les détails'),
(518, 'view_details', 'en', 'View details'),
(519, 'loading', 'fr', 'Chargement...'),
(520, 'loading', 'en', 'Loading...'),
(521, 'error_loading', 'fr', 'Erreur lors du chargement des détails.'),
(522, 'error_loading', 'en', 'Error loading details.'),
(523, 'order_details', 'fr', 'Détails de la commande'),
(524, 'order_details', 'en', 'Order Details'),
(525, 'delivery_address', 'fr', 'Adresse de livraison'),
(526, 'delivery_address', 'en', 'Delivery Address'),
(527, 'mosaic_details', 'fr', 'Détails de la mosaïque'),
(528, 'mosaic_details', 'en', 'Mosaic Details'),
(529, 'size', 'fr', 'Taille'),
(530, 'size', 'en', 'Size'),
(531, 'palette', 'fr', 'Palette'),
(532, 'palette', 'en', 'Palette'),
(533, 'colors_count', 'fr', 'Nombre de couleurs'),
(534, 'colors_count', 'en', 'Colors Count'),
(535, 'documents', 'fr', 'Documents téléchargeables'),
(536, 'documents', 'en', 'Downloadable Documents'),
(537, 'download_image', 'fr', 'Télécharger l’image finale'),
(538, 'download_image', 'en', 'Download Final Image'),
(539, 'contact_support', 'fr', 'Contacter le service client'),
(540, 'contact_support', 'en', 'Contact Customer Support'),
(541, 'estimated_shipping', 'fr', 'Date d\'expédition estimée'),
(542, 'estimated_shipping', 'en', 'Estimated shipping date'),
(543, 'estimated_delivery', 'fr', 'Date de livraison estimée'),
(544, 'estimated_delivery', 'en', 'Estimated delivery date'),
(545, 'order_summary_subject', 'fr', 'Résumé de votre commande'),
(546, 'order_summary_subject', 'en', 'Order summary'),
(547, 'order_summary_intro', 'fr', 'Bonjour, voici le récapitulatif de votre commande.'),
(548, 'order_summary_intro', 'en', 'Hello, here is your order summary.'),
(549, 'order_summary_address', 'fr', 'Adresse de livraison'),
(550, 'order_summary_address', 'en', 'Delivery address'),
(551, 'order_summary_order_id', 'fr', 'Numéro de commande'),
(552, 'order_summary_order_id', 'en', 'Order ID'),
(553, 'order_summary_price', 'fr', 'Montant payé'),
(554, 'order_summary_price', 'en', 'Amount paid'),
(555, 'order_summary_footer', 'fr', 'Merci pour votre commande !'),
(556, 'order_summary_footer', 'en', 'Thank you for your order!'),
(557, 'mail_error', 'fr', 'Erreur lors de l\'envoi de l\'email : '),
(558, 'mail_error', 'en', 'Error sending email: '),
(559, 'password_invalid', 'fr', 'Le mot de passe doit contenir au moins 8 caractères, dont une majuscule, une minuscule, un chiffre et un caractère spécial.'),
(560, 'password_invalid', 'en', 'The password must contain at least 8 characters, including one uppercase letter, one lowercase letter, one number, and one special character.'),
(561, 'username_exists', 'fr', 'Ce nom d’utilisateur ou cette adresse email existe déjà, veuillez en choisir un autre.'),
(562, 'username_exists', 'en', 'This username or the email already exists, please choose another one.'),
(565, 'register_error', 'fr', 'Une erreur est survenue, veuillez réessayer.'),
(566, 'register_error', 'en', 'An error occurred, please try again.'),
(567, 'review_mosaics_title', 'fr', 'Voici vos mosaïques générées'),
(568, 'review_mosaics_title', 'en', 'Your generated mosaics'),
(569, 'review_mosaics_subtitle', 'fr', 'Voici vos mosaïques générées'),
(570, 'review_mosaics_subtitle', 'en', 'Here are your generated mosaics'),
(571, 'blue_version', 'fr', 'Couleurs bleue accentuée'),
(572, 'blue_version', 'en', 'Blue enhanced version'),
(573, 'red_version', 'fr', 'Nuances rouge accentuées'),
(574, 'red_version', 'en', 'Red enhanced version'),
(575, 'bw_version', 'fr', 'Noir & Blanc'),
(576, 'bw_version', 'en', 'Black & White'),
(577, 'select', 'fr', 'Sélectionner'),
(578, 'select', 'en', 'Select'),
(579, 'size', 'fr', 'Taille'),
(580, 'size', 'en', 'Size'),
(581, 'colors', 'fr', 'Nombre de couleurs'),
(582, 'colors', 'en', 'Colors'),
(583, 'estimated_price', 'fr', 'Prix estimé'),
(584, 'estimated_price', 'en', 'Estimated price'),
(585, 'confirm_choice', 'fr', 'Valider mon choix'),
(586, 'confirm_choice', 'en', 'Confirm my choice'),
(587, 'filterblue', 'en', 'Blue'),
(588, 'filterblue', 'fr', 'Bleu'),
(589, 'filterred', 'en', 'Red'),
(590, 'filterred', 'fr', 'Rouge'),
(591, 'filterwhite', 'en', 'Black & White'),
(592, 'filterwhite', 'fr', 'Noir & Blanc'),
(593, 'cv_phone', 'fr', 'Téléphone :'),
(594, 'cv_phone', 'en', 'Phone:'),
(595, 'cv_email_label', 'fr', 'Email :'),
(596, 'cv_email_label', 'en', 'Email:'),
(597, 'cv_address', 'fr', 'Adresse :'),
(598, 'cv_address', 'en', 'Address:'),
(599, 'cv_education_title', 'fr', 'Formations'),
(600, 'cv_education_title', 'en', 'Education'),
(601, 'cv_experience_title', 'fr', 'Expériences'),
(602, 'cv_experience_title', 'en', 'Experience'),
(603, 'cv_projects_title', 'fr', 'Projets'),
(604, 'cv_projects_title', 'en', 'Projects'),
(605, 'cv_skills_title', 'fr', 'Compétences'),
(606, 'cv_skills_title', 'en', 'Skills'),
(607, 'cv_languages_title', 'fr', 'Langues'),
(608, 'cv_languages_title', 'en', 'Languages'),
(609, 'cv_but2', 'fr', 'BUT 2 Informatique à l\'IUT de Marne-la-Vallée (septembre 2025 - actuellement)'),
(610, 'cv_but2', 'en', '2nd Year University Bachelor of Technology in CS at IUT Marne-la-Vallée (September 2025 - Present)'),
(611, 'cv_but1', 'fr', 'BUT 1 Informatique à l\'IUT de Fontainebleau (septembre 2024 - Juin 2025)'),
(612, 'cv_but1', 'en', '1st Year University Bachelor of Technology in CS at IUT Fontainebleau (September 2024 - June 2025)'),
(613, 'cv_bac', 'fr', 'Baccalauréat général (Mathématiques et NSI) (septembre 2023 - juin 2024) [mention assez bien]'),
(614, 'cv_bac', 'en', 'High School Diploma (Mathematics and CS) (September 2023 - June 2024) [Honors]'),
(615, 'cv_pix', 'fr', 'Certification PIX (janvier 2024)'),
(616, 'cv_pix', 'en', 'PIX Digital Skills Certification (January 2024)'),
(617, 'cv_brevet', 'fr', 'Brevet des collèges (2020 - 2021) [mention bien]'),
(618, 'cv_brevet', 'en', 'Middle School Diploma (2020 - 2021) [High Honors]'),
(619, 'cv_exp_prof_title', 'fr', 'Professeur en informatique'),
(620, 'cv_exp_prof_title', 'en', 'Computer Science Tutor'),
(621, 'cv_exp_prof_desc', 'fr', 'Suivi pédagogique de lycéens. Aide aux devoirs, création d\'exercices et projets Python.'),
(622, 'cv_exp_prof_desc', 'en', 'Pedagogical support for high school students. Homework help, creation of exercises and Python projects.'),
(623, 'cv_exp_dominos_title', 'fr', 'Responsable de services chez Domino\'s Pizza'),
(624, 'cv_exp_dominos_title', 'en', 'Shift Manager at Domino\'s Pizza'),
(625, 'cv_exp_dominos_desc', 'fr', 'Gestion d\'équipe sous pression. Gestion administrative (traçabilité, comptabilité). Livraison et préparation.'),
(626, 'cv_exp_dominos_desc', 'en', 'Team management under pressure. Administrative management (traceability, accounting). Delivery and food preparation.'),
(627, 'cv_exp_animator_title', 'fr', 'Animateur centre nautique'),
(628, 'cv_exp_animator_title', 'en', 'Water Sports Center Animator'),
(629, 'cv_exp_animator_desc', 'fr', 'Maintenance des machines, surveillance des enfants, vente de confiseries.'),
(630, 'cv_exp_animator_desc', 'en', 'Machine maintenance, supervision of children, confectionery sales.'),
(631, 'cv_cat_web', 'fr', 'Développement Web'),
(632, 'cv_cat_web', 'en', 'Web Development'),
(633, 'cv_cat_soft', 'fr', 'Développement Logiciel'),
(634, 'cv_cat_soft', 'en', 'Software Development'),
(635, 'cv_cat_arch', 'fr', 'Architecture et Réseau'),
(636, 'cv_cat_arch', 'en', 'Architecture & Network'),
(637, 'cv_proj_img2brick', 'fr', 'Plateforme transformant une image en mosaïque Lego. Architecture C (pavage), Java (conversion), Web (commande).'),
(638, 'cv_proj_img2brick', 'en', 'Platform transforming images into Lego mosaics. C architecture (tiling), Java (conversion), Web (ordering).'),
(639, 'cv_proj_critique', 'fr', 'Conception et développement d\'un site web interactif dédié à la critique et à la notation de films.'),
(640, 'cv_proj_critique', 'en', 'Design and development of an interactive website dedicated to movie reviews and ratings.'),
(641, 'cv_proj_ecommerce', 'fr', 'Site e-commerce proposant livraison et click-and-collect pour les commerçants locaux.'),
(642, 'cv_proj_ecommerce', 'en', 'E-commerce site offering delivery and click-and-collect for local merchants.'),
(643, 'cv_proj_samegame', 'fr', 'Jeu \"Same Game\" en Java. Gestion des événements graphiques et algorithmes de suppression.'),
(644, 'cv_proj_samegame', 'en', '\"Same Game\" in Java. Graphical event management and block removal algorithms.'),
(645, 'cv_proj_morpion', 'fr', 'Implémentation du jeu du Morpion en Python.'),
(646, 'cv_proj_morpion', 'en', 'Implementation of Tic-Tac-Toe in Python.'),
(647, 'cv_proj_blocus', 'fr', 'Jeu de stratégie type Blocus en langage C (norme C89), réalisé en binôme.'),
(648, 'cv_proj_blocus', 'en', 'Blokus-style strategy game in C (C89 standard), developed in a pair.'),
(649, 'cv_proj_buckshot', 'fr', 'Jeu de stratégie et hasard type roulette russe en Python.'),
(650, 'cv_proj_buckshot', 'en', 'Strategy and chance game (Russian roulette style) in Python.'),
(651, 'cv_proj_horses', 'fr', 'Simulation de course en Python. POO et multi-threading.'),
(652, 'cv_proj_horses', 'en', 'Horse racing simulation in Python. OOP and multi-threading.'),
(653, 'cv_proj_sysadmin', 'fr', 'Installation et config serveur : OpenSSH, Samba, DNS et Web.'),
(654, 'cv_proj_sysadmin', 'en', 'Server installation and config: OpenSSH, Samba, DNS, and Web.'),
(655, 'cv_proj_dualboot', 'fr', 'Mise en place d\'un dual boot (Arch Linux / Windows 7) sur VM distante.'),
(656, 'cv_proj_dualboot', 'en', 'Setup of a dual boot (Arch Linux / Windows 7) on a remote VM.'),
(657, 'cv_skill_prog', 'fr', 'Programmation'),
(658, 'cv_skill_prog', 'en', 'Programming'),
(659, 'cv_skill_maint', 'fr', 'Maintenance informatique'),
(660, 'cv_skill_maint', 'en', 'IT Maintenance'),
(661, 'cv_skill_maint_desc', 'fr', 'Dépannage, installation matérielle/logicielle'),
(662, 'cv_skill_maint_desc', 'en', 'Troubleshooting, hardware/software setup'),
(663, 'cv_skill_project', 'fr', 'Gestion de projet'),
(664, 'cv_skill_project', 'en', 'Project Management'),
(665, 'cv_skill_project_desc', 'fr', 'Collaboration sur projets informatiques'),
(666, 'cv_skill_project_desc', 'en', 'Collaboration on IT projects'),
(667, 'cv_skill_team', 'fr', 'Gestion d\'une équipe'),
(668, 'cv_skill_team', 'en', 'Team Management'),
(669, 'cv_skill_net', 'fr', 'Réseau'),
(670, 'cv_skill_net', 'en', 'Network'),
(671, 'cv_lang_fr', 'fr', 'Français (langue maternelle)'),
(672, 'cv_lang_fr', 'en', 'French (Native)'),
(673, 'cv_lang_en', 'fr', 'Anglais (niveau scolaire)'),
(674, 'cv_lang_en', 'en', 'English (Academic/Basic)');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id_user` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `username` varchar(50) NOT NULL,
  `etat` enum('invalide','valide') NOT NULL DEFAULT 'invalide',
  `mode` varchar(10) DEFAULT NULL,
  `mdp` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id_user`, `email`, `username`, `etat`, `mode`, `mdp`) VALUES
(25, 'amine.mourali77@gmail.com', 'AIRMINE', 'valide', NULL, '$2y$10$4irVPBsOp4r8vOLaezYLkO0MLm4P4k6M3q1.CVaWs8BalRfLR4/te');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `commande`
--
ALTER TABLE `commande`
  ADD PRIMARY KEY (`id_commande`),
  ADD KEY `id_user` (`id_user`),
  ADD KEY `fk_commande_cord` (`id_cord`),
  ADD KEY `idx_id_images` (`id_images`);

--
-- Indexes for table `cord_banquaire`
--
ALTER TABLE `cord_banquaire`
  ADD PRIMARY KEY (`id_cord`);

--
-- Indexes for table `images`
--
ALTER TABLE `images`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_user` (`id_user`);

--
-- Indexes for table `tokens`
--
ALTER TABLE `tokens`
  ADD PRIMARY KEY (`id_token`),
  ADD KEY `id_user` (`id_user`);

--
-- Indexes for table `translations`
--
ALTER TABLE `translations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id_user`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `commande`
--
ALTER TABLE `commande`
  MODIFY `id_commande` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=78;

--
-- AUTO_INCREMENT for table `cord_banquaire`
--
ALTER TABLE `cord_banquaire`
  MODIFY `id_cord` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=90;

--
-- AUTO_INCREMENT for table `images`
--
ALTER TABLE `images`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=111;

--
-- AUTO_INCREMENT for table `tokens`
--
ALTER TABLE `tokens`
  MODIFY `id_token` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=54;

--
-- AUTO_INCREMENT for table `translations`
--
ALTER TABLE `translations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=675;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `commande`
--
ALTER TABLE `commande`
  ADD CONSTRAINT `commande_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `users` (`id_user`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_commande_cord` FOREIGN KEY (`id_cord`) REFERENCES `cord_banquaire` (`id_cord`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_commande_images` FOREIGN KEY (`id_images`) REFERENCES `images` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `images`
--
ALTER TABLE `images`
  ADD CONSTRAINT `images_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `users` (`id_user`) ON DELETE CASCADE;

--
-- Constraints for table `tokens`
--
ALTER TABLE `tokens`
  ADD CONSTRAINT `tokens_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `users` (`id_user`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
