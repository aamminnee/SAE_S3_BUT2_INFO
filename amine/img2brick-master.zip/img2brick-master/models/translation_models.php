<?php

require_once __DIR__ . '/../vendor/autoload.php';
use Dotenv\Dotenv;

class TranslationModel {
    private $conn;

    public function __construct() {
        $dotenv = Dotenv::createImmutable(__DIR__ . "/../");
        $dotenv->load();
        $host = $_ENV['DB_HOST'];
        $user = $_ENV['DB_USER'];
        $pass = $_ENV['DB_PASS'];
        $dbname = $_ENV['DB_NAME'];
        $this->conn = mysqli_connect($host, $user, $pass, $dbname);
        if (!$this->conn) {
            die("Erreur de connexion : " . mysqli_connect_error());
        }
    }

    // get translations for a given language
    public function getTranslations($lang) {
        $query = "SELECT key_name, texte FROM translations WHERE lang = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("s", $lang);
        $stmt->execute();
        $result = $stmt->get_result();
        $translations = [];
        while ($row = $result->fetch_assoc()) {
            $translations[$row['key_name']] = $row['texte'];
        }
        return $translations;
    }
}
