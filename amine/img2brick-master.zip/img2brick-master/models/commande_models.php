<?php

require_once __DIR__ . '/../vendor/autoload.php'; 
use Dotenv\Dotenv;

class CommandeModel {
    private $conn;

    // load environment variables and establish database connection
    public function __construct() { 
        $dotenv = Dotenv::createImmutable(__DIR__ . "/../");
        $dotenv->load();
        $host = $_ENV['DB_HOST'];
        $user = $_ENV['DB_USER'];
        $pass = $_ENV['DB_PASS'];
        $dbname = $_ENV['DB_NAME'];
        $this->conn = mysqli_connect($host, $user, $pass, $dbname);
        if (!$this->conn) {
            die("Erreur de connexion : " . mysqli_connect_error());
        }
    }

    // insert new order details into the database
    public function saveCommande($user_id, $images_id, $adresse, $code_postal, $ville, $pays, $telephone, $montant, $id_cord) {
        $sql = "INSERT INTO commande 
                (id_user, id_images, adresse, code_postal, ville, pays, telephone, montant, id_cord) 
                VALUES  (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
        $stmt = mysqli_prepare($this->conn, $sql);
        mysqli_stmt_bind_param($stmt, "iisssssdi", 
            $user_id, 
            $images_id,    
            $adresse, 
            $code_postal, 
            $ville, 
            $pays, 
            $telephone, 
            $montant, $id_cord
        );
        $result = mysqli_stmt_execute($stmt);
        if ($result) {
            $id_commande = mysqli_insert_id($this->conn);
            mysqli_stmt_close($stmt);
            return $id_commande;
        } else {
            mysqli_stmt_close($stmt);
            return false;
        }
    }

    // fetch order details by id including associated image data
    public function getCommandeById($commande_id) {
        $sql = "SELECT commande.*, images.identifiant as image_identifiant, images.type as image_type 
                FROM commande 
                INNER JOIN images ON commande.id_images = images.id 
                WHERE id_commande = ?";
        
        $stmt = mysqli_prepare($this->conn, $sql);
        mysqli_stmt_bind_param($stmt, "i", $commande_id);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        $commande = mysqli_fetch_assoc($result);
        mysqli_stmt_close($stmt);
        return $commande;
    }

    // fetch all orders for a specific user ordered by date
    public function getCommandeByUserId($user_id) {
        $sql = "SELECT commande.*, images.identifiant as image_identifiant, images.type as image_type
                FROM commande 
                INNER JOIN images ON commande.id_images = images.id 
                WHERE commande.id_user = ?
                ORDER BY commande.date_commande DESC"; 
        $stmt = mysqli_prepare($this->conn, $sql);
        mysqli_stmt_bind_param($stmt, "i", $user_id);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        $commandes = [];
        while ($row = mysqli_fetch_assoc($result)) {
            $commandes[] = $row;
        }
        mysqli_stmt_close($stmt);
        return $commandes;
    }

    // calculate order status based on elapsed time since order date
    public function getCommandeStatusById($id_commande) {
        $sql = "SELECT date_commande FROM commande WHERE id_commande = ?";
        $stmt = mysqli_prepare($this->conn, $sql);
        mysqli_stmt_bind_param($stmt, "i", $id_commande);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        $row = mysqli_fetch_assoc($result);
        mysqli_stmt_close($stmt);
        if (!$row || empty($row['date_commande'])) {
            return "Inconnue";
        }
        // compute difference between order date and current date
        $dateCommande = new DateTime($row['date_commande']);
        $now = new DateTime();
        $interval = $now->diff($dateCommande);
        $days = (int)$interval->format('%a'); 
        if ($days < 2) {
            return "En attente";
        } elseif ($days < 7) {
            return "Expédiée";
        } else {
            return "Livrée";
        }
    }
}
?>