<?php

require_once __DIR__ . '/../vendor/autoload.php'; 
use Dotenv\Dotenv;

class ImagesModel {
    private $conn;

    public function __construct() { 
        $dotenv = Dotenv::createImmutable(__DIR__ . "/../");
        $dotenv->load();
        $host = $_ENV['DB_HOST'];
        $user = $_ENV['DB_USER'];
        $pass = $_ENV['DB_PASS'];
        $dbname = $_ENV['DB_NAME'];
        $this->conn = mysqli_connect($host, $user, $pass, $dbname);
        if (!$this->conn) {
            die("Erreur de connexion : " . mysqli_connect_error());
        }
    }

    // save image directly in database
    public function saveImageBlob($image_name, $user_id, $imageData) {
        $sql = "INSERT INTO images (identifiant, id_user, image) VALUES (?, ?, ?)";
        $stmt = mysqli_prepare($this->conn, $sql);
        mysqli_stmt_bind_param($stmt, "sib", $image_name, $user_id, $null);
        mysqli_stmt_send_long_data($stmt, 2, $imageData);
        $result = mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);
        return $result;
    }

    // update image blob in database
    public function updateImageBlob($old_name, $new_name, $user_id, $imageData) {
        $sql = "UPDATE images SET identifiant = ?, image = ? WHERE identifiant = ? AND id_user = ?";
        $stmt = mysqli_prepare($this->conn, $sql);
        mysqli_stmt_bind_param($stmt, "sbsi", $new_name, $null, $old_name, $user_id);
        mysqli_stmt_send_long_data($stmt, 1, $imageData);
        $result = mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);
        return $result;
    }

    // get last image name by user
    public function getLastImageByUser($user_id) {
        $sql = "SELECT identifiant FROM images WHERE id_user = ? ORDER BY id DESC LIMIT 1";
        $stmt = mysqli_prepare($this->conn, $sql);
        mysqli_stmt_bind_param($stmt, "i", $user_id);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        return mysqli_fetch_assoc($result);
    }

    // get last image ID by user
    public function getLastIdImageByUser($user_id, $name_image) {
        $sql = "SELECT id FROM images WHERE id_user = ? AND identifiant = ? ORDER BY id DESC LIMIT 1";
        $stmt = mysqli_prepare($this->conn, $sql);
        mysqli_stmt_bind_param($stmt, "is", $user_id, $name_image);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        return mysqli_fetch_assoc($result);
    }

    // get last image blob by user
    public function getLastImageBlobByUser($user_id, $name_image) {
        $sql = "SELECT image FROM images WHERE id_user = ? AND identifiant = ? ORDER BY id DESC LIMIT 1";
        $stmt = mysqli_prepare($this->conn, $sql);
        mysqli_stmt_bind_param($stmt, "is", $user_id, $name_image);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        return mysqli_fetch_assoc($result);
    }

    // set type of image (blue, red, bw)
    public function setImageType($image_name, $type) {
        $sql = "UPDATE images SET type = ? WHERE identifiant = ?";
        $stmt = mysqli_prepare($this->conn, $sql);
        mysqli_stmt_bind_param($stmt, "ss", $type, $image_name);
        $result = mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);
        return $result;
    }

    // get image type
    public function getImageType($image_name) {
        $sql = "SELECT type FROM images WHERE identifiant = ? LIMIT 1";
        $stmt = mysqli_prepare($this->conn, $sql);
        mysqli_stmt_bind_param($stmt, "s", $image_name);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        return mysqli_fetch_assoc($result); 
    }

    // get id_image by identifiant
    public function getIdImageByIdentifiant($image_name) {
        $sql = "SELECT id FROM images WHERE identifiant = ? LIMIT 1";
        $stmt = mysqli_prepare($this->conn, $sql); 
        mysqli_stmt_bind_param($stmt, "s", $image_name);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        return mysqli_fetch_assoc($result);
    }

    // Get image details by ID
    public function getImageById($id) {
        $sql = "SELECT * FROM images WHERE id = ?";
        $stmt = mysqli_prepare($this->conn, $sql);
        mysqli_stmt_bind_param($stmt, "i", $id);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        return mysqli_fetch_assoc($result);
    }
}