<?php

require_once __DIR__ . '/../vendor/autoload.php'; 
use Dotenv\Dotenv;

class UsersModel {
    private $conn;

    public function __construct() { 
        $dotenv = Dotenv::createImmutable(__DIR__ . "/../");
        $dotenv->load();
        $host = $_ENV['DB_HOST'];
        $user = $_ENV['DB_USER'];
        $pass = $_ENV['DB_PASS'];
        $dbname = $_ENV['DB_NAME'];
        $this->conn = mysqli_connect($host, $user, $pass, $dbname);
        if (!$this->conn) {
            die("Erreur de connexion : " . mysqli_connect_error());
        }
    }

    // get full user info by id
    public function getUserById($id_user) {
        $request = mysqli_prepare($this->conn, "SELECT * FROM users WHERE id_user = ?");
        mysqli_stmt_bind_param($request, "i", $id_user);
        mysqli_stmt_execute($request);
        $res = mysqli_stmt_get_result($request);
        return $res->fetch_assoc();
    }

    // get user by username
    public function getUserByUsername($username) {
        $request = mysqli_prepare($this->conn, "SELECT id_user, mdp FROM users WHERE username = ?");
        mysqli_stmt_bind_param($request, "s", $username);
        mysqli_stmt_execute($request);
        $res = mysqli_stmt_get_result($request);
        return $res->fetch_assoc();
    }

    // get username by id
    public function getUsernameById($id_user) {
        $request = mysqli_prepare($this->conn, "SELECT username FROM users WHERE id_user = ?");
        mysqli_stmt_bind_param($request, "i", $id_user);
        mysqli_stmt_execute($request);
        $res = mysqli_stmt_get_result($request);
        return $res->fetch_assoc();
    }

    // get user status by id
    public function getStatusById($id_user) {
        $request = mysqli_prepare($this->conn, "SELECT etat FROM users WHERE id_user = ?");
        mysqli_stmt_bind_param($request, "i", $id_user);
        mysqli_stmt_execute($request);
        $res = mysqli_stmt_get_result($request);
        return $res->fetch_assoc();
    }
    
    // add user in database
    public function addUser($email, $username, $password) {
        $hashed = password_hash($password, PASSWORD_DEFAULT);
        $request = mysqli_prepare($this->conn, "INSERT INTO users (email, username, etat, mdp) VALUES (?, ?, 'invalide', ?)");
        mysqli_stmt_bind_param($request, "sss", $email, $username, $hashed);
        try {
            return mysqli_stmt_execute($request);
        } catch (mysqli_sql_exception $e) {
            // check for duplicate entry error
            if (strpos($e->getMessage(), 'Duplicate entry') !== false) {
                return "duplicate";
            }
            return false;
        }
    }

    // activate user
    public function activateUser($id_user) {
        $request = mysqli_prepare($this->conn, "UPDATE users SET etat = 'valide' WHERE id_user = ?");
        mysqli_stmt_bind_param($request, "i", $id_user);
        return mysqli_stmt_execute($request);
    }

    // update user password
    public function setPassword($id_user, $password) {
        $hashed = password_hash($password, PASSWORD_DEFAULT);
        $request = mysqli_prepare($this->conn, "UPDATE users SET mdp = ? WHERE id_user = ?");
        mysqli_stmt_bind_param($request, "si", $hashed, $id_user);
        return mysqli_stmt_execute($request);
    }

    // get user email by id
    public function getEmailById($id_user) {
        $request = mysqli_prepare($this->conn, "SELECT email FROM users WHERE id_user = ?");
        mysqli_stmt_bind_param($request, "i", $id_user);
        mysqli_stmt_execute($request);
        $res = mysqli_stmt_get_result($request);
        return $res->fetch_assoc();
    }

    // get user mode by id
    public function getModeById($id_user) {
        $request = mysqli_prepare($this->conn, "SELECT mode FROM users WHERE id_user = ?");
        mysqli_stmt_bind_param($request, "i", $id_user);
        mysqli_stmt_execute($request);
        $res = mysqli_stmt_get_result($request);
        $row = $res->fetch_assoc();
        return $row ? $row['mode'] : null;
    }

    // set user mode by id
    public function setModeById($id_user, $mode) {
        $request = mysqli_prepare($this->conn, "UPDATE users SET mode = ? WHERE id_user = ?");
        mysqli_stmt_bind_param($request, "si", $mode, $id_user);
        return mysqli_stmt_execute($request);
    }
}