<?php
// start session if not already active
if (session_status() === PHP_SESSION_NONE) session_start(); 

// include configuration and translation models
require_once __DIR__ . '/../control/config.php';
require_once __DIR__ . '/../models/translation_models.php';

// initialize translation model and load language strings
$translationModel = new TranslationModel();
$t = $translationModel->getTranslations($_SESSION['lang'] ?? 'en');

?>

<!DOCTYPE html>
<html lang="<?= htmlspecialchars($_SESSION['lang'] ?? 'en') ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $t['verify_title'] ?? 'Account Verification' ?></title>
    
    <link rel="stylesheet" href="<?= $BASE_URL ?>/views/CSS/style.css">
    <link rel="stylesheet" href="<?= $BASE_URL ?>/views/CSS/verify_views.css">
    <link rel="stylesheet" href="<?= $BASE_URL ?>/views/CSS/footer.css">
</head>
<body>

<?php 
// include header component
include __DIR__ . '/header.php'; 
?>

<main class="verify-container">

    <h2><?= $t['verify_header'] ?? 'Enter Verification Code' ?></h2>

    <form action="<?= $BASE_URL ?>/control/user_control.php?action=tokenForm" method="post">
        
        <label for="token">Code (6 digits)</label>
        
        <input type="text" name="token" id="token" maxlength="6" required 
               placeholder="123456" autocomplete="off">
               
        <div style="font-size: 0.9rem; color: #666; margin-bottom: 20px; text-align: center;">
            Check your emails for the code.
        </div>

        <button type="submit"><?= $t['verify_button'] ?? 'Validate' ?></button>
    </form>

    <?php 
    // show back link only if user is not fully authenticated
    if (!isset($_SESSION['status']) || $_SESSION['status'] == 'invalide'): ?>
        <p class="back-link">
            <a href="<?= $BASE_URL ?>/views/login_views.php">
                <?= $t['login_link_text'] ?? 'Back to Login' ?>
            </a>
        </p>
    <?php endif; ?>

</main>

<?php 
// include footer component
include __DIR__ . '/footer.html'; 
?>
</body>
</html>