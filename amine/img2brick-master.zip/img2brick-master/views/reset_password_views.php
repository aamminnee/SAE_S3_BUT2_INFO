<?php
// start session if not already active
if (session_status() === PHP_SESSION_NONE) session_start();
// include configuration and translation models
require_once __DIR__ . '/../control/config.php';
require_once __DIR__ . '/../models/translation_models.php';

// initialize translation model if translations are missing
if (!isset($t)) {
    $translationModel = new TranslationModel();
    $lang = $_SESSION['lang'] ?? 'fr';
    $t = $translationModel->getTranslations($lang);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $t['reset_password_title'] ?? 'Reset your password' ?></title>
    
    <link rel="stylesheet" href="<?=$BASE_URL?>/views/CSS/style.css">
    <link rel="stylesheet" href="<?=$BASE_URL?>/views/CSS/reset_password_views.css?v=<?= time() ?>">
</head>
<body>

<?php 
// include header component
include __DIR__ . '/header.php'; 
?>

<div class="footer-actions">
    <a href="<?=$BASE_URL?>/views/images_views.php" class="btn-lego btn-lego-yellow">
        <?= $t['return_home'] ?? 'Return to Home' ?>
    </a>
</div>

<main class="reset-container">

    <h1 class="page-title"><?= $t['reset_password_header'] ?? 'Reset Password' ?></h1>

    <?php 
    // display alert message if set
    if (isset($message)): ?>
        <div class="alert-box">
            <?= htmlspecialchars($message) ?>
        </div>
    <?php endif; ?>

    <div class="reset-card">
        <div class="card-icon"></div>
        
        <form action="<?=$BASE_URL?>/control/user_control.php" method="post" class="reset-form">
            
            <div class="input-group">
                <label for="password"><?= $t['new_password_label'] ?? 'New password' ?></label>
                <input type="password" name="password" id="password" required placeholder="********">
            </div>

            <div class="input-group">
                <label for="password_confirm"><?= $t['confirm_password_label'] ?? 'Confirm password' ?></label>
                <input type="password" name="password_confirm" id="password_confirm" required placeholder="********">
            </div>

            <button type="submit" name="reset_password" class="btn-lego btn-lego-blue">
                <?= $t['reset_password_button'] ?? 'Reset Password' ?>
            </button>
        </form>
    </div>
</main>

<?php 
// include footer component
include __DIR__ . '/footer.html'; 
?>
</body>
</html>