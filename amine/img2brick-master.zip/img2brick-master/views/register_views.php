<?php
// start session if not already active
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// include configuration and translation models
require_once __DIR__ . '/../control/config.php';
require_once __DIR__ . '/../models/translation_models.php';

// initialize translation model and load translations
$translationModel = new TranslationModel();
$t = $translationModel->getTranslations($_SESSION['lang'] ?? 'en');

// define base url if not set
if (!isset($BASE_URL)) {
    $BASE_URL = defined('BASE_URL') ? BASE_URL : ($_ENV['BASE_URL'] ?? 'http://localhost/img2brick');
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $t['register_title'] ?? 'Register' ?></title>
    
    <link rel="stylesheet" href="<?= $BASE_URL ?>/views/CSS/style.css">
    <link rel="stylesheet" href="<?= $BASE_URL ?>/views/CSS/login_views_style.css">
    <link rel="stylesheet" href="<?= $BASE_URL ?>/views/CSS/footer.css">
</head>
<body>

<?php 
// include header component
include __DIR__ . '/header.php'; 
?>

<main class="login-container">

    <?php 
    // display registration specific messages from session
    if (isset($_SESSION['register_message'])): ?>
        <div class="error-box">
            <?= htmlspecialchars($_SESSION['register_message'], ENT_QUOTES, 'UTF-8') ?>
        </div>
        <?php 
        // clear message after display
        unset($_SESSION['register_message']); // On efface le message après affichage ?>
    <?php endif; ?>

    <?php 
    // display general error messages
    if (isset($message)): ?>
        <div class="error-box">
            <?= htmlspecialchars($message, ENT_QUOTES, 'UTF-8') ?>
        </div>
    <?php endif; ?>

    <h2><?= $t['register_header'] ?? 'Create Account' ?></h2>

    <form action="<?= $BASE_URL ?>/control/user_control.php" method="post">
        
        <label for="email"><?= $t['email_label'] ?? 'Email Address' ?></label>
        <input type="email" name="email" id="email" required placeholder="ex: mario@lego.com">

        <label for="username"><?= $t['username_label'] ?? 'Username' ?></label>
        <input type="text" name="username" id="username" required placeholder="ex: MasterBuilder">

        <label for="password"><?= $t['password_label'] ?? 'Password' ?></label>
        <input type="password" name="password" id="password" required placeholder="••••••••">
        
        <div style="font-size: 0.85rem; color: #666; margin-top: -15px; margin-bottom: 20px; line-height: 1.4;">
            Min. 8 characters, 1 uppercase, 1 lowercase, 1 number, 1 special char.
        </div>

        <button type="submit" name="register"><?= $t['register_button'] ?? 'Sign Up' ?></button>
    </form>

    <p class="register-link">
        <?= $t['already_have_account'] ?? 'Already have an account?' ?> 
        <a href="<?= $BASE_URL ?>/views/login_views.php">
            <?= $t['login_link'] ?? 'Log in here' ?>
        </a>
    </p>

</main>

<?php 
// include footer component
include __DIR__ . '/footer.html'; 
?>
</body>
</html>