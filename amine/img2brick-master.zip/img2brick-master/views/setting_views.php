<?php
// include configuration file
require_once __DIR__ . '/../control/config.php';

// ensure translation array is initialized
$t = $t ?? [];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $t['setting_title'] ?? 'Settings' ?></title>
    
    <link rel="stylesheet" href="<?=$BASE_URL?>/views/CSS/style.css">
    <link rel="stylesheet" href="<?=$BASE_URL?>/views/CSS/setting_views_style.css">
</head>
<body>

<?php 
// include header component
include __DIR__ . '/header.php'; 
?>

<main class="setting-container">
    
    <h1 class="page-title"><?= $t['setting_title'] ?? 'Settings' ?></h1>

    <div class="settings-grid">
        
        <div class="button-group">
            <a href="<?=$BASE_URL?>/control/setting_control.php?action=setLanguage&lang=fr" class="btn-lego btn-lego-blue">
                <?= $t['french'] ?? 'Français' ?>
            </a>
            <a href="<?=$BASE_URL?>/control/setting_control.php?action=setLanguage&lang=en" class="btn-lego btn-lego-red">
                <?= $t['english'] ?? 'English' ?>
            </a>
        </div>

        <?php 
        // check if user is logged in to display account options
        if (isset($_SESSION['username'])): ?>
        <div class="setting-card">
            <div class="card-icon"></div>
            <h3><?= $t['account'] ?? 'Account' ?></h3>
            <p class="user-info"><?= htmlspecialchars($_SESSION['username']) ?></p>
            <div class="button-group">
                <a href="<?=$BASE_URL?>/views/compte_views.php" class="btn-lego btn-lego-green">
                    <?= $t['my_account'] ?? 'Access My Account' ?>
                </a>
            </div>
        </div>
        <?php endif; ?>

    </div>

    <div class="footer-actions">
        <a href="<?=$BASE_URL?>/views/images_views.php" class="return-link">
            <?= $t['return_home'] ?? '← Return to Home' ?>
        </a>
    </div>

</main>

<?php 
// include footer component
include __DIR__ . '/footer.html'; 
?>
</body>
</html>