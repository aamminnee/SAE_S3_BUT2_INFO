<?php
// start session if not already started
if (session_status() === PHP_SESSION_NONE) session_start();
// include required configuration and models
require_once __DIR__ . '/../control/config.php';
require_once __DIR__ . '/../models/translation_models.php';
require_once __DIR__ . '/../models/images_models.php';

// initialize translation model and get current language data
$translationModel = new TranslationModel();
$t = $translationModel->getTranslations($_SESSION['lang'] ?? 'en');

// validate user authentication and status
if (!isset($_SESSION['user_id']) || ($_SESSION['status'] ?? '') !== 'valide') {
    header("Location: " . $BASE_URL . "/views/login_views.php");
    exit;
}

// retrieve the last processed image and determine its visual type
$images_model = new ImagesModel();
$imageName = $_SESSION['last_image'] ?? 'default.png';
$imageData = $images_model->getImageType($imageName);
$type = $imageData['type'] ?? 'default';

// define css filter based on the image palette type
$filterCSS = match($type) {
    'blue' => 'contrast(1.1) hue-rotate(180deg) saturate(1.2)',
    'red'  => 'contrast(1.1) hue-rotate(340deg) saturate(1.5)',
    'bw'   => 'grayscale(100%) contrast(1.1)',
    default => 'none'
};
?>

<!DOCTYPE html>
<html lang="<?= htmlspecialchars($_SESSION['lang'] ?? 'en') ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $t['checkout_title'] ?? 'Checkout' ?></title>
    
    <link rel="stylesheet" href="<?= $BASE_URL ?>/views/CSS/style.css">
    <link rel="stylesheet" href="<?= $BASE_URL ?>/views/CSS/payment_views.css">
    <link rel="stylesheet" href="<?= $BASE_URL ?>/views/CSS/footer.css">
</head>
<body>

<?php include __DIR__ . '/header.php'; ?>

<main class="payment-container">

    <h2 class="page-title"><?= $t['checkout_title'] ?? 'Finalize my order' ?></h2>

    <div class="checkout-layout">
        
        <aside class="summary-panel lego-box">
            <h3><?= $t['order_summary'] ?? 'Order Summary' ?></h3>
            
            <div class="img-wrapper">
                <img src="<?= $BASE_URL ?>/control/get_image.php?img=<?= urlencode($imageName) ?>" 
                     style="filter: <?= $filterCSS ?>;" 
                     alt="Mosaic Preview">
            </div>
            
            <div class="price-tag">
                <span><?= $t['estimated_price'] ?? 'Total' ?></span>
                <strong>12.99 €</strong>
            </div>
            
            <p class="secure-note">Secure Checkout</p>
        </aside>

        <section class="form-panel lego-box">
            <form action="<?= $BASE_URL ?>/control/payment_control.php" method="POST">
                
                <div class="form-group">
                    <div class="legend-header">
                        <span class="icon"></span> <?= $t['shipping_info'] ?? 'Shipping' ?>
                    </div>
                    
                    <label><?= $t['address'] ?? 'Address' ?></label>
                    <input type="text" name="address" placeholder="123 Brick Lane" value="2 rue Albert Einstein" required>
                    
                    <div class="row-inputs">
                        <div class="half">
                            <label><?= $t['postal_code'] ?? 'Zip Code' ?></label>
                            <input type="text" name="postal" placeholder="75000" value="77420" required>
                        </div>
                        <div class="half">
                            <label><?= $t['city'] ?? 'City' ?></label>
                            <input type="text" name="city" placeholder="Paris" value="Champs sur Marne" required>
                        </div>
                    </div>

                    <div class="row-inputs">
                        <div class="half">
                            <label><?= $t['country'] ?? 'Country' ?></label>
                            <input type="text" name="country" value="France" required>
                        </div>
                        <div class="half">
                            <label><?= $t['phone'] ?? 'Phone' ?></label>
                            <input type="tel" name="phone" value="0160957500" required>
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <div class="legend-header">
                        <span class="icon"></span> <?= $t['payment'] ?? 'Payment' ?>
                    </div>
                    
                    <label>Card Number</label>
                    <input type="text" name="card_number" value="4242 4242 4242 4242" required class="input-card">
                    
                    <div class="row-inputs">
                        <div class="half">
                            <label>Expiry</label>
                            <input type="text" name="expiry" value="12/34" placeholder="MM/YY" required>
                        </div>
                        <div class="half">
                            <label>CVC</label>
                            <input type="text" name="cvc" value="123" placeholder="123" required>
                        </div>
                    </div>
                </div>

                <button type="submit" class="pay-btn"><?= $t['confirm_order'] ?? 'Confirm Order' ?></button>
                
                <p class="simulation-info"><?= $t['payment_info'] ?? 'Simulation only - No real charge' ?></p>
            </form>
        </section>

    </div>
</main>

<?php include __DIR__ . '/footer.html'; ?>
</body>
</html>