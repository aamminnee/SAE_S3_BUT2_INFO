<?php
// check if session is started, otherwise start it
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// load configuration and base url
require_once __DIR__ . '/../control/config.php';
$BASE_URL = $_ENV['BASE_URL'] ?? '';

// initialize translations based on session language
require_once __DIR__ . '/../models/translation_models.php';
$translationModel = new TranslationModel(); 
$t = $translationModel->getTranslations($_SESSION['lang'] ?? 'en');

// load environment variables using dotenv
require_once __DIR__ . '/../vendor/autoload.php'; 
use Dotenv\Dotenv;
$dotenv = Dotenv::createImmutable(__DIR__ . "/../");
$dotenv->load();
?>

<link rel="stylesheet" href="<?=$BASE_URL?>/views/CSS/style.css">
<link rel="stylesheet" href="<?=$BASE_URL?>/views/CSS/header_style.css">
<link rel="stylesheet" href="<?= $BASE_URL ?>/views/CSS/footer.css">

<header class="main-header">
    <div class="header-container">
        
        <nav class="header-nav">
            <a href="<?=$BASE_URL?>/views/images_views.php" class="logo-container">
                <img src="<?=$BASE_URL?>/images/logo.png" alt="Logo img2brick" class="header-logo">
            </a>

            <a href="<?=$BASE_URL?>/views/images_views.php" class="nav-link"><?= $t['home'] ?? 'Home' ?></a>
            <a href="<?=$BASE_URL?>/views/compte_views.php" class="nav-link"><?= $t['my_account'] ?? 'Account' ?></a>
            <a href="<?=$BASE_URL?>/control/setting_control.php" class="nav-link"><?= $t['setting_title'] ?? 'Settings' ?></a>
            
            <?php 
            // display orders link only for logged-in users
            if (isset($_SESSION['username'])): ?>
                <a href="<?=$BASE_URL?>/control/commande_control.php" class="nav-link">Commandes</a>
            <?php endif; ?>
        </nav>

        <div class="header-auth">
            <?php 
            // check authentication status to show user profile or login/register options
            if (isset($_SESSION['username'])): ?>
                <div class="user-badge">
                    <span class="greeting">Hello,</span>
                    <span class="username"><?= htmlspecialchars($_SESSION['username']) ?></span>
                </div>
                <a href="<?=$BASE_URL?>/control/user_control.php?action=logout" class="btn btn-logout"><?= $t['logout'] ?? 'Logout' ?></a>
            <?php else: ?>
                <a href="<?=$BASE_URL?>/views/login_views.php" class="btn btn-login"><?= $t['login'] ?? 'Login' ?></a>
                <a href="<?=$BASE_URL?>/views/register_views.php" class="btn btn-register"><?= $t['register'] ?? 'Register' ?></a>
            <?php endif; ?>
        </div>

    </div>
</header>