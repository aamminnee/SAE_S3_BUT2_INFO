<?php
// start session if not already active
if (session_status() === PHP_SESSION_NONE) session_start();

// include configuration and translation models
require_once __DIR__ . '/../control/config.php';
require_once __DIR__ . '/../models/translation_models.php';

// initialize translation model and load translations
$translationModel = new TranslationModel();
$t = $translationModel->getTranslations($_SESSION['lang'] ?? 'en');

// validate user authentication and status
if (!isset($_SESSION['user_id']) || ($_SESSION['status'] ?? '') !== 'valide') {
    header("Location: " . $BASE_URL . "/views/login_views.php");
    exit;
}

// retrieve image parameter and validate existence
$image = $_GET['img'] ?? null;
if (!$image) {
    echo "<p>Image not found</p>";
    exit;
}

// set display size and update session with current image
$displaySize = $_SESSION['boardSize'] ?? 64;
$_SESSION['last_image'] = $image;
?>

<!DOCTYPE html>
<html lang="<?= htmlspecialchars($_SESSION['lang'] ?? 'en') ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $t['review_mosaics_title'] ?? 'Review' ?></title>
    
    <link rel="stylesheet" href="<?= $BASE_URL ?>/views/CSS/style.css">
    <link rel="stylesheet" href="<?= $BASE_URL ?>/views/CSS/review_images_views_style.css">
    <link rel="stylesheet" href="<?= $BASE_URL ?>/views/CSS/footer.css">
</head>
<body>

<?php 
// include header component
include __DIR__ . '/header.php'; 
?>

<main class="review-container">
    
    <h2><?= $t['review_mosaics_title'] ?? 'Choose your style' ?></h2>
    <p class="subtitle"><?= $t['review_mosaics_subtitle'] ?? 'Select a version to proceed.' ?></p>

    <form action="../control/images_control.php" method="POST">
        <div class="cards-grid">
            
            <label class="lego-card card-blue">
                <input type="radio" name="choice" value="blue" required>
                <div class="card-inner">
                    <div class="card-header">
                        <h3><?= $t['blue_version'] ?? 'Blue' ?></h3>
                        <span class="badge">Classic</span>
                    </div>
                    
                    <div class="img-wrapper">
                        <img src="<?= $BASE_URL ?>/control/get_image.php?img=<?= urlencode($image) ?>" alt="Blue">
                    </div>

                    <div class="card-details">
                        <p><strong>Size:</strong> <?= $displaySize ?>x<?= $displaySize ?> studs</p>
                        <p><strong>Theme:</strong> Blue Palette</p>
                    </div>

                    <div class="card-footer">
                        <span class="price">12.99 €</span>
                        <span class="check-icon">✔</span>
                    </div>
                </div>
            </label>

            <label class="lego-card card-red">
                <input type="radio" name="choice" value="red">
                <div class="card-inner">
                    <div class="card-header">
                        <h3><?= $t['red_version'] ?? 'Red' ?></h3>
                        <span class="badge">Warm</span>
                    </div>
                    
                    <div class="img-wrapper">
                        <img src="<?= $BASE_URL ?>/control/get_image.php?img=<?= urlencode($image) ?>" alt="Red">
                    </div>

                    <div class="card-details">
                        <p><strong>Size:</strong> <?= $displaySize ?>x<?= $displaySize ?> studs</p>
                        <p><strong>Theme:</strong> Red Palette</p>
                    </div>

                    <div class="card-footer">
                        <span class="price">12.99 €</span>
                        <span class="check-icon">✔</span>
                    </div>
                </div>
            </label>

            <label class="lego-card card-bw">
                <input type="radio" name="choice" value="bw">
                <div class="card-inner">
                    <div class="card-header">
                        <h3><?= $t['bw_version'] ?? 'B & W' ?></h3>
                        <span class="badge">Art</span>
                    </div>
                    
                    <div class="img-wrapper">
                        <img src="<?= $BASE_URL ?>/control/get_image.php?img=<?= urlencode($image) ?>" alt="BW">
                    </div>

                    <div class="card-details">
                        <p><strong>Size:</strong> <?= $displaySize ?>x<?= $displaySize ?> studs</p>
                        <p><strong>Theme:</strong> Monochrome</p>
                    </div>

                    <div class="card-footer">
                        <span class="price">12.99 €</span>
                        <span class="check-icon">✔</span>
                    </div>
                </div>
            </label>

        </div>

        <button type="submit" class="confirm-btn" name="mosaic"><?= $t['confirm_choice'] ?? 'Order This Mosaic' ?></button>
    </form>

</main>

<?php 
// include footer component
include __DIR__ . '/footer.html'; 
?>
</body>
</html>