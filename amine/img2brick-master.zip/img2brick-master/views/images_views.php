<?php
// start session if not active
if (session_status() === PHP_SESSION_NONE) session_start();

// clear previous session data specific to image processing
unset($_SESSION['selected_mosaic']);
unset($_SESSION['last_image']);
unset($_SESSION['boardSize']);
unset($_SESSION['mode']);

// include configuration and translation model
require_once __DIR__ . '/../control/config.php'; 

require_once __DIR__ . '/../models/translation_models.php';
// load translations based on session language
$translationModel = new TranslationModel();
$t = $translationModel->getTranslations($_SESSION['lang'] ?? 'en');

// check if user is logged in and has a valid status
$isValidUser = isset($_SESSION['user_id']) && ($_SESSION['status'] ?? '') === 'valide';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $t['upload_title'] ?? 'img2brick - Upload Image' ?></title>
    
    <link rel="stylesheet" href="<?= $BASE_URL ?>/views/CSS/style.css">
    <link rel="stylesheet" href="<?= $BASE_URL ?>/views/CSS/images_views.css">
</head>

<body>
    <?php include __DIR__ . '/header.php'; ?>

    <main class="container">
        
        <h1>img2brick</h1>
        <p><?= $t['upload_subtitle'] ?? 'Turn your images into brick mosaics!' ?></p>

        <img src="<?= $BASE_URL ?>/images/mosaique_chat.png" alt="Décoration" class="bg-image-html">

        <div id="drop-zone">
            <p id="drop-text">
                <?= $t['drop_instructions'] ?? 'Drag & drop your image here...' ?>
            </p>
        </div>

        <label id="fileLabel" for="fileInput"><?= $t['choose_file'] ?? 'Choose a file' ?></label>
        <input type="file" id="fileInput" accept=".jpg,.jpeg,.png,.webp">

        <div id="message"></div>
        <div id="preview" style="display:none;"></div>
        <button id="continueButton"><?= $t['continue'] ?? 'Continue' ?></button>


    </main>

    <script>
        // pass user validation status to javascript
        const isValidUser = <?= json_encode($isValidUser) ?>;
    </script>
    <script src="<?= $BASE_URL ?>/views/JS/drag&drop.js"></script>
    
    <?php include __DIR__ . '/footer.html'; ?>
</body>
</html>