<?php
if (session_status() === PHP_SESSION_NONE) {
    // start session if not already active
    session_start();
}

// include configuration and translation model files
require_once __DIR__ . '/../control/config.php';
require_once __DIR__ . '/../models/translation_models.php';
// instantiate translation model and load translations based on session language
$translationModel = new TranslationModel();
$lang = $_SESSION['lang'] ?? 'fr';
$t = $translationModel->getTranslations($lang);
?>

<!DOCTYPE html>
<html lang="<?= htmlspecialchars($lang) ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CV - Amine AISSYNE</title>
    <link rel="stylesheet" href="<?=$BASE_URL?>/views/CSS/style.css">
    <link rel="stylesheet" href="<?=$BASE_URL?>/views/CSS/CV_AMINE.css">
</head>
<?php 
// include shared header component
include __DIR__ . '/header.php'; 
?>
<body>
    <div class="container">
        <h1>Amine AISSYNE</h1>
        <div class="contact">
            <p><strong><?= $t['cv_phone'] ?? 'Téléphone :' ?></strong> 07 77 05 42 34</p>
            <p><strong><?= $t['cv_email_label'] ?? 'Email :' ?></strong> <a href="mailto:amine.aissyne06@icloud.com">amine.aissyne06@icloud.com</a></p>
            <p><strong><?= $t['cv_address'] ?? 'Adresse :' ?></strong> Meaux, 77100</p>
        </div>

        <div class="section">
            <h2><?= $t['cv_education_title'] ?? 'Formations' ?></h2>
            <ul>
                <li><?= $t['cv_but2'] ?></li>
                <li><?= $t['cv_but1'] ?></li>
                <li><?= $t['cv_bac'] ?></li>
                <li><?= $t['cv_pix'] ?></li>
                <li><?= $t['cv_brevet'] ?></li>
            </ul>
        </div>

        <div class="section">
            <h2><?= $t['cv_experience_title'] ?? 'Expériences' ?></h2>
            <ul>
                <li><strong><?= $t['cv_exp_prof_title'] ?></strong> (Meaux) (2023 - <?= ($lang == 'fr' ? 'Présent' : 'Present') ?>)<br>
                    <?= $t['cv_exp_prof_desc'] ?>
                </li>
                <li><strong><?= $t['cv_exp_dominos_title'] ?></strong> (Meaux) (2023 - <?= ($lang == 'fr' ? 'Présent' : 'Present') ?>)<br>
                    <?= $t['cv_exp_dominos_desc'] ?>
                </li>
                <li><strong><?= $t['cv_exp_animator_title'] ?></strong> (Jablines) (2022)<br>
                    <?= $t['cv_exp_animator_desc'] ?>
                </li>
            </ul>
        </div>

        <div class="section projects">
            <h2><?= $t['cv_projects_title'] ?? 'Projets' ?></h2>

            <h3><?= $t['cv_cat_web'] ?></h3>
            <ul>
                <li><strong>Img2Brick</strong> (Nov 2025)<br>
                    <?= $t['cv_proj_img2brick'] ?>
                </li>
                <li><strong>Site de critique</strong> (Mai 2025)<br>
                    <?= $t['cv_proj_critique'] ?>
                </li>
                <li><strong>Site e-commerce</strong> (Jan 2025)<br>
                    <?= $t['cv_proj_ecommerce'] ?>
                </li>
            </ul>

            <h3><?= $t['cv_cat_soft'] ?></h3>
            <ul>
                <li><strong>Same Game</strong> (Avr 2025)<br>
                    <?= $t['cv_proj_samegame'] ?>
                </li>
                <li><strong>Morpion</strong> (Jan 2025)<br>
                    <?= $t['cv_proj_morpion'] ?>
                </li>
                <li><strong>Blocus</strong> (2024)<br>
                    <?= $t['cv_proj_blocus'] ?>
                </li>
                <li><strong>Buckshot Roulette</strong> (2024)<br>
                    <?= $t['cv_proj_buckshot'] ?>
                </li>
                <li><strong>Jeu de chevaux</strong> (Déc 2023)<br>
                    <?= $t['cv_proj_horses'] ?>
                </li>
            </ul>

            <h3><?= $t['cv_cat_arch'] ?></h3>
            <ul>
                <li><strong>Administration Système</strong> (2024-2025)<br>
                    <?= $t['cv_proj_sysadmin'] ?>
                </li>
                <li><strong>Dual Boot</strong> (Déc 2024)<br>
                    <?= $t['cv_proj_dualboot'] ?>
                </li>
            </ul>
        </div>

        <div class="section skills">
            <h2><?= $t['cv_skills_title'] ?? 'Compétences' ?></h2>
            <ul>
                <li><strong><?= $t['cv_skill_prog'] ?> :</strong> C89, HTML/CSS, SQL, Python, Java, C, PHP</li>
                <li><strong><?= $t['cv_skill_maint'] ?> :</strong> <?= $t['cv_skill_maint_desc'] ?></li>
                <li><strong><?= $t['cv_skill_project'] ?> :</strong> <?= $t['cv_skill_project_desc'] ?></li>
                <li><strong><?= $t['cv_skill_team'] ?> :</strong> Gestion d'équipe professionnelle</li>
                <li><strong><?= $t['cv_skill_net'] ?> :</strong> TCP/IP, HTTP, SSH, FTP, DNS, SMTP, POP3, IMAP</li>
            </ul>
        </div>

        <div class="section languages">
            <h2><?= $t['cv_languages_title'] ?? 'Langues' ?></h2>
            <ul>
                <li>
                    <?= $t['cv_lang_fr'] ?>
                    <div class="skill-bar"><span data-level="native"></span></div>
                </li>
                <li>
                    <?= $t['cv_lang_en'] ?>
                    <div class="skill-bar"><span data-level="basic"></span></div>
                </li>
            </ul>
        </div>
    </div>
</body>
<?php 
// include shared footer component
include __DIR__ . '/footer.html'; 
?>
</html>