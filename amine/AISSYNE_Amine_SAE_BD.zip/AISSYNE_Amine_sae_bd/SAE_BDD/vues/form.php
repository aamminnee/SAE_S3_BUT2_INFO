<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Gestion des Stocks</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .alert-card { border-left: 5px solid #dc3545; }
        .text-danger { color: #dc3545; font-weight: bold; }
        .badge-danger { background-color: #dc3545; color: white; padding: 4px 8px; border-radius: 4px; font-size: 0.8em; }
        .badge-in { background-color: #d4edda; color: #155724; padding: 4px 8px; border-radius: 4px; font-weight: bold; }
        .badge-out { background-color: #f8d7da; color: #721c24; padding: 4px 8px; border-radius: 4px; font-weight: bold; }
        .qty-plus { color: green; font-weight: bold; }
        .qty-minus { color: red; font-weight: bold; }
    </style>
</head>
<body>
    
    <div class="main-content">
        
        <!-- ALERTES -->
        <?php if (!empty($alerts)): ?>
        <div class="card alert-card" style="margin-bottom: 20px;">
            <h2 style="color: #dc3545; margin-top: 0;">Alertes : Stock Critique (< 10)</h2>
            <table class="table">
                <thead>
                    <tr>
                        <th>Référence</th>
                        <th>Article</th>
                        <th>Stock Restant</th>
                        <th>État</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($alerts as $alert): ?>
                    <tr style="background-color: #fff5f5;">
                        <td><?php echo htmlspecialchars($alert['reference']); ?></td>
                        <td><?php echo htmlspecialchars($alert['name']); ?></td>
                        <td class="text-danger" style="font-size: 1.2em;">
                            <?php echo $alert['current_stock']; ?>
                        </td>
                        <td><span class="badge-danger">STOCK BAS</span></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php endif; ?>
        <div class="card">
            <h1>Entrée de Stock</h1>
            <?php if(isset($message) && $message) echo "<div class='alert success'>$message</div>"; ?>
            <form method="POST" action="index.php">
                <div class="form-group">
                    <label>Sélectionner l'article :</label>
                    <select name="id_item" required>
                        <option value="">-- Choisir un produit --</option>
                        <?php foreach($items as $item): ?>
                            <!-- MODIFICATION ICI : On affiche le stock actuel dans la liste -->
                            <option value="<?php echo $item['id_Item']; ?>">
                                <?php 
                                    // On vérifie si current_stock existe (grâce au nouveau modèle), sinon 0
                                    $stock = isset($item['current_stock']) ? $item['current_stock'] : 0;
                                    echo htmlspecialchars($item['reference'] . ' - ' . $item['name']) . " (Stock actuel: $stock)"; 
                                ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Quantité à ajouter :</label>
                    <input type="number" name="quantity" min="1" placeholder="Ex: 50" required>
                </div>
                <button type="submit" class="btn-success">Valider l'entrée</button>
            </form>
        </div>

        <!-- HISTORIQUE -->
        <div class="card mt-20">
            <h3>Historique Global (Entrées & Sorties)</h3>
            <table class="table">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Type</th>
                        <th>Référence</th>
                        <th>Produit</th>
                        <th>Quantité</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(empty($history)): ?>
                        <tr><td colspan="5" class="text-center">Aucun mouvement récent.</td></tr>
                    <?php else: ?>
                        <?php foreach($history as $row): ?>
                        <tr>
                            <td><?php echo date("d/m/Y", strtotime($row['date_mouvement'])); ?></td>
                            <td>
                                <?php if($row['type'] == 'ENTREE'): ?>
                                    <span class="badge-in">ENTRÉE</span>
                                <?php else: ?>
                                    <span class="badge-out">SORTIE</span>
                                <?php endif; ?>
                            </td>
                            <td><?php echo htmlspecialchars($row['reference']); ?></td>
                            <td><?php echo htmlspecialchars($row['name']); ?></td>
                            <td class="<?php echo ($row['type'] == 'ENTREE') ? 'qty-plus' : 'qty-minus'; ?>">
                                <?php echo ($row['type'] == 'ENTREE') ? '+' : '-'; ?><?php echo $row['quantity']; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>