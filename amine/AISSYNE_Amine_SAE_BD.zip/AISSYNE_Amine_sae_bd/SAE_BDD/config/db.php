<?php
class Database {
    private $host;
    private $db_name;
    private $username;
    private $password;
    public $conn;

    public function __construct() {
        $this->loadEnv();
        $this->host = $_ENV['DB_HOST'];
        $this->db_name = $_ENV['DB_NAME'];
        $this->username = $_ENV['DB_USER'];
        $this->password = $_ENV['DB_PASS'];
    }

    private function loadEnv() {
        // Le chemin vers le .env (on remonte d'un dossier car on est dans config/)
        $envFile = __DIR__ . '/../.env';
        if (file_exists($envFile)) {
            // Lit le fichier ligne par ligne
            $lines = file($envFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
            foreach ($lines as $line) {
                // Ignore les commentaires commençant par #
                if (strpos(trim($line), '#') === 0) {
                    continue;
                }
                // Sépare la clé et la valeur au niveau du signe =
                if (strpos($line, '=') !== false) {
                    list($name, $value) = explode('=', $line, 2);
                    $name = trim($name);
                    $value = trim($value);
                    // Stocke dans $_ENV et $_SERVER
                    if (!array_key_exists($name, $_SERVER) && !array_key_exists($name, $_ENV)) {
                        putenv(sprintf('%s=%s', $name, $value));
                        $_ENV[$name] = $value;
                        $_SERVER[$name] = $value;
                    }
                }
            }
        }
    }

    public function getConnection() {
        $this->conn = new mysqli($this->host, $this->username, $this->password, $this->db_name);
        if ($this->conn->connect_error) {
            die("Erreur de connexion : " . $this->conn->connect_error);
        }

        // Forcer l'encodage en UTF-8
        $this->conn->set_charset("utf8");

        return $this->conn;
    }
}
?>