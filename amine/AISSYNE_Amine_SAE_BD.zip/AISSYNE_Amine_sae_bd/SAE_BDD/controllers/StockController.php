<?php
require_once 'models/Stock.php';
require_once 'config/db.php';

class StockController {
    private $db;
    private $stock;

    public function __construct() {
        $database = new Database();
        $this->db = $database->getConnection();
        $this->stock = new Stock($this->db);
    }

    public function index() {
        $message = '';
        // Traitement du formulaire d'ajout de stock
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            // On vérifie que les champs existent
            if (isset($_POST['id_item']) && isset($_POST['quantity'])) {
                $id_item = $_POST['id_item'];
                $quantity = $_POST['quantity'];
                // Appel au modèle pour insérer en base
                if ($this->stock->addEntry($id_item, $quantity)) {
                    $message = "Stock ajouté avec succès !";
                } else {
                    $message = "Erreur technique lors de l'ajout.";
                }
            }
        }

        $items = $this->stock->getAllItems();
        $history = $this->stock->getHistory();
        
        // On appelle la nouvelle méthode basée sur la Vue
        $alerts = $this->stock->getAlertsFromView();

        include 'vues/form.php';
    }
}
?>