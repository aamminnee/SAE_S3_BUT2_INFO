<?php
// On charge uniquement le contrôleur de stock
require_once 'controllers/StockController.php';

// On lance directement la page de stock
$controller = new StockController();
$controller->index();
?>