<?php
class Stock {
    private $conn;

    public function __construct($db) {
        $this->conn = $db;
    }

    public function getAllItems() {
        $query = "SELECT id_Item, reference, name, current_stock FROM View_StockStatus ORDER BY name";
        $result = $this->conn->query($query);
        return $result->fetch_all(MYSQLI_ASSOC);
    }

    public function addEntry($id_item, $quantity) {
        $query = "INSERT INTO StockEntry (id_Item, quantity, date_import) VALUES (?, ?, NOW())";
        $stmt = $this->conn->prepare($query);
        if(!$stmt) { return false; }
        $stmt->bind_param("ii", $id_item, $quantity);
        return $stmt->execute();
    }

    public function getHistory() {
        $query = "
            (
                SELECT 
                    s.date_import AS date_mouvement, 
                    s.quantity, 
                    'ENTREE' AS type, 
                    i.name, 
                    i.reference 
                FROM StockEntry s 
                JOIN Item i ON s.id_Item = i.id_Item
            )
            UNION ALL
            (
                SELECT 
                    co.order_date AS date_mouvement, 
                    oi.quantity, 
                    'SORTIE' AS type, 
                    i.name, 
                    i.reference 
                FROM OrderItem oi
                JOIN CustomerOrder co ON oi.id_Order = co.id_Order
                JOIN Item i ON oi.id_Item = i.id_Item
            )
            ORDER BY date_mouvement DESC
        ";
        $result = $this->conn->query($query);
        return $result->fetch_all(MYSQLI_ASSOC);
    }

    public function getAlertsFromView() {
        $query = "SELECT * FROM View_StockStatus WHERE alert_status = 'OUI'";
        $result = $this->conn->query($query);
        if ($result) {
            return $result->fetch_all(MYSQLI_ASSOC);
        }
        return [];
    }
}
?>