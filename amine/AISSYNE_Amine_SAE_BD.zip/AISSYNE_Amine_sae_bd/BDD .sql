-- ============================================================
-- DUMP FINAL COMPLET (Procédures + Tables + Vues + Triggers)
-- Compatible MariaDB (AlwaysData) & MySQL
-- ============================================================

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `SAE`
--

DELIMITER $$

-- --------------------------------------------------------
-- 1. PROCÉDURES STOCKÉES (Nettoyées & Corrigées)
-- --------------------------------------------------------

-- Procédure d'installation complète
DROP PROCEDURE IF EXISTS `create_all_tables`$$
CREATE PROCEDURE `create_all_tables` ()
BEGIN
    -- Ordre strict pour respecter les clés étrangères
    CALL create_save_customer_table();
    CALL create_item_table();
    CALL create_image_table();
    CALL create_mosaic_table();
    CALL create_customer_image_table();
    
    CALL create_customer_table();
    CALL create_bank_details_table();
    CALL create_customer_order_table();
    CALL create_order_item_table();
    CALL create_invoice_table();
    CALL create_stockentry();
    CALL create_factory_order_table();
    CALL create_mosaic_composition_table();
END$$

-- Procédure de vérification de stock pour une Mosaïque
DROP PROCEDURE IF EXISTS `check_mosaic_stock`$$
CREATE PROCEDURE `check_mosaic_stock` (
    IN p_id_Mosaic INT,
    OUT p_is_available BOOLEAN
)
BEGIN
    DECLARE v_missing_items INT;

    SELECT COUNT(*) 
    INTO v_missing_items
    FROM MosaicComposition mc
    JOIN View_StockStatus vss ON mc.id_Item = vss.id_Item
    WHERE mc.id_Mosaic = p_id_Mosaic
    AND vss.current_stock < mc.quantity_needed;

    IF v_missing_items = 0 THEN
        SET p_is_available = TRUE;
    ELSE
        SET p_is_available = FALSE;
    END IF;

    -- Sécurité si pas de composition
    IF (SELECT COUNT(*) FROM MosaicComposition WHERE id_Mosaic = p_id_Mosaic) = 0 THEN
        SET p_is_available = FALSE;
    END IF;
END$$

-- Procédure SaveCustomer
DROP PROCEDURE IF EXISTS `create_save_customer_table`$$
CREATE PROCEDURE `create_save_customer_table` ()
BEGIN
    CREATE TABLE IF NOT EXISTS SaveCustomer (
        id_SaveCustomer INT AUTO_INCREMENT PRIMARY KEY,
        first_name VARCHAR(100) NOT NULL,
        last_name VARCHAR(100) NOT NULL,
        email VARCHAR(150) NOT NULL,
        adress VARCHAR(255),
        postal_code VARCHAR(20), 
        city VARCHAR(255)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
END$$

-- Procédure Customer
DROP PROCEDURE IF EXISTS `create_customer_table`$$
CREATE PROCEDURE `create_customer_table` ()
BEGIN
    CREATE TABLE IF NOT EXISTS Customer (
        id_Customer INT AUTO_INCREMENT PRIMARY KEY,
        password VARCHAR(255) NOT NULL,
        phone CHAR(10),
        id_SaveCustomer INT,
        FOREIGN KEY (id_SaveCustomer) REFERENCES SaveCustomer(id_SaveCustomer)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
END$$

-- Procédure Item
DROP PROCEDURE IF EXISTS `create_item_table`$$
CREATE PROCEDURE `create_item_table` ()
BEGIN
    CREATE TABLE IF NOT EXISTS Item (
        id_Item INT AUTO_INCREMENT PRIMARY KEY,
        reference VARCHAR(50) NOT NULL,
        name VARCHAR(150) NOT NULL,
        color VARCHAR(50),
        unit_price DECIMAL(10,2) NOT NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
END$$

-- Procédure FactoryOrder
DROP PROCEDURE IF EXISTS `create_factory_order_table`$$
CREATE PROCEDURE `create_factory_order_table` ()
BEGIN
    CREATE TABLE IF NOT EXISTS FactoryOrder (
        id_FactoryOrder INT AUTO_INCREMENT PRIMARY KEY,
        id_Item INT NOT NULL,
        quantity INT NOT NULL,
        price DECIMAL(10,2) NOT NULL,
        order_date DATE NOT NULL DEFAULT (CURRENT_DATE),
        FOREIGN KEY (id_Item) REFERENCES Item(id_Item)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
END$$

-- Procédure StockEntry
DROP PROCEDURE IF EXISTS `create_stockentry`$$
CREATE PROCEDURE `create_stockentry` ()
BEGIN
    CREATE TABLE IF NOT EXISTS StockEntry (
        id_Stock INT NOT NULL AUTO_INCREMENT,
        id_Item INT NOT NULL,
        date_import DATE NOT NULL DEFAULT (CURRENT_DATE),
        quantity INT NOT NULL,
        PRIMARY KEY (id_Stock),
        CONSTRAINT fk_stock_item FOREIGN KEY (id_Item) REFERENCES Item(id_Item)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
END$$

-- Procédure Invoice
DROP PROCEDURE IF EXISTS `create_invoice_table`$$
CREATE PROCEDURE `create_invoice_table` ()
BEGIN
    CREATE TABLE IF NOT EXISTS Invoice (
        id_Invoice INT AUTO_INCREMENT PRIMARY KEY,
        invoice_number VARCHAR(50) NOT NULL,
        issue_date DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        total_amount DECIMAL(10,2) NOT NULL,
        id_Order INT UNIQUE NOT NULL,
        order_date DATETIME NOT NULL,
        order_status VARCHAR(20) NOT NULL,
        id_Bank_Details INT,
        id_SaveCustomer INT,
        FOREIGN KEY (id_Order) REFERENCES CustomerOrder(id_Order),
        FOREIGN KEY (id_Bank_Details) REFERENCES BankDetails(id_Bank_Details),
        FOREIGN KEY (id_SaveCustomer) REFERENCES SaveCustomer(id_SaveCustomer)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
END$$

-- Procédure CustomerOrder
DROP PROCEDURE IF EXISTS `create_customer_order_table`$$
CREATE PROCEDURE `create_customer_order_table` ()
BEGIN
    CREATE TABLE IF NOT EXISTS CustomerOrder (
        id_Order INT AUTO_INCREMENT PRIMARY KEY,
        order_date DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        status VARCHAR(20) NOT NULL,
        total_amount DECIMAL(10,2) NOT NULL,
        id_Customer INT NOT NULL,
        id_Image INT,
        id_Mosaic INT,
        FOREIGN KEY (id_Customer) REFERENCES Customer(id_Customer),
        FOREIGN KEY (id_Image) REFERENCES CustomerImage(id_Image),
        FOREIGN KEY (id_Mosaic) REFERENCES Mosaic(id_Mosaic)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
END$$

-- Procédure OrderItem
DROP PROCEDURE IF EXISTS `create_order_item_table`$$
CREATE PROCEDURE `create_order_item_table` ()
BEGIN
    CREATE TABLE IF NOT EXISTS OrderItem (
        id_Order INT NOT NULL,
        id_Item INT NOT NULL,
        quantity INT NOT NULL,
        unit_price_snapshot DECIMAL(10,2) NOT NULL,
        PRIMARY KEY (id_Order, id_Item),
        FOREIGN KEY (id_Order) REFERENCES CustomerOrder(id_Order),
        FOREIGN KEY (id_Item) REFERENCES Item(id_Item)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
END$$

-- Procédure BankDetails
DROP PROCEDURE IF EXISTS `create_bank_details_table`$$
CREATE PROCEDURE `create_bank_details_table` ()
BEGIN
    CREATE TABLE IF NOT EXISTS BankDetails (
        id_Bank_Details INT AUTO_INCREMENT PRIMARY KEY,
        id_Customer INT NOT NULL,
        FOREIGN KEY (id_Customer) REFERENCES Customer(id_Customer),
        bank_name VARCHAR(150) NOT NULL,
        card_number VARCHAR(16) NOT NULL,
        expire_at DATE NOT NULL,
        cvc VARCHAR(3) NOT NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
END$$

-- Procédure Image (Autres)
DROP PROCEDURE IF EXISTS `create_image_table`$$
CREATE PROCEDURE `create_image_table` ()
BEGIN
    CREATE TABLE IF NOT EXISTS Image (
        id_Image INT AUTO_INCREMENT PRIMARY KEY,
        filename VARCHAR(255) NOT NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
END$$

DROP PROCEDURE IF EXISTS `create_customer_image_table`$$
CREATE PROCEDURE `create_customer_image_table` ()
BEGIN
    CREATE TABLE IF NOT EXISTS CustomerImage (
        id_Image INT AUTO_INCREMENT PRIMARY KEY,
        upload_date DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
END$$

DROP PROCEDURE IF EXISTS `create_mosaic_table`$$
CREATE PROCEDURE `create_mosaic_table` ()
BEGIN
    CREATE TABLE IF NOT EXISTS Mosaic (
        id_Mosaic INT AUTO_INCREMENT PRIMARY KEY,
        pattern_type VARCHAR(50) NOT NULL,
        generation_date DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
END$$

DROP PROCEDURE IF EXISTS `create_mosaic_composition_table`$$
CREATE PROCEDURE `create_mosaic_composition_table` ()
BEGIN
    CREATE TABLE IF NOT EXISTS MosaicComposition (
        id_Mosaic INT NOT NULL,
        id_Item INT NOT NULL,
        quantity_needed INT NOT NULL,
        PRIMARY KEY (id_Mosaic, id_Item),
        FOREIGN KEY (id_Mosaic) REFERENCES Mosaic(id_Mosaic),
        FOREIGN KEY (id_Item) REFERENCES Item(id_Item)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
END$$

-- Procédure Calcul Stock
DROP PROCEDURE IF EXISTS `get_all_items_stock`$$
CREATE PROCEDURE `get_all_items_stock` ()
BEGIN
    SELECT 
        i.id_Item, 
        i.reference, 
        i.name, 
        i.unit_price,
        (IFNULL(entries.total_in, 0) - IFNULL(sales.total_out, 0)) AS calculated_stock
    FROM Item i
    LEFT JOIN (
        SELECT id_Item, SUM(quantity) AS total_in
        FROM StockEntry
        GROUP BY id_Item
    ) entries ON i.id_Item = entries.id_Item
    LEFT JOIN (
        SELECT id_Item, SUM(quantity) AS total_out
        FROM OrderItem
        GROUP BY id_Item
    ) sales ON i.id_Item = sales.id_Item;
END$$

DELIMITER ;

-- --------------------------------------------------------
-- 2. STRUCTURES DES TABLES (Avec Collation Corrigée)
-- --------------------------------------------------------

-- Table SaveCustomer
CREATE TABLE IF NOT EXISTS `SaveCustomer` (
  `id_SaveCustomer` int NOT NULL AUTO_INCREMENT,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `adress` varchar(255) DEFAULT NULL,
  `postal_code` varchar(20) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_SaveCustomer`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Table Customer
CREATE TABLE IF NOT EXISTS `Customer` (
  `id_Customer` int NOT NULL AUTO_INCREMENT,
  `password` varchar(255) NOT NULL,
  `phone` char(10) DEFAULT NULL,
  `id_SaveCustomer` int DEFAULT NULL,
  PRIMARY KEY (`id_Customer`),
  KEY `id_SaveCustomer` (`id_SaveCustomer`),
  CONSTRAINT `Customer_ibfk_1` FOREIGN KEY (`id_SaveCustomer`) REFERENCES `SaveCustomer` (`id_SaveCustomer`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Table Item
CREATE TABLE IF NOT EXISTS `Item` (
  `id_Item` int NOT NULL AUTO_INCREMENT,
  `reference` varchar(50) NOT NULL,
  `name` varchar(150) NOT NULL,
  `color` varchar(50) DEFAULT NULL,
  `unit_price` decimal(10,2) NOT NULL,
  PRIMARY KEY (`id_Item`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Table StockEntry
CREATE TABLE IF NOT EXISTS `StockEntry` (
  `id_Stock` int NOT NULL AUTO_INCREMENT,
  `id_Item` int NOT NULL,
  `date_import` date NOT NULL DEFAULT (curdate()),
  `quantity` int NOT NULL,
  PRIMARY KEY (`id_Stock`),
  KEY `fk_stock_item` (`id_Item`),
  CONSTRAINT `fk_stock_item` FOREIGN KEY (`id_Item`) REFERENCES `Item` (`id_Item`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Table FactoryOrder
CREATE TABLE IF NOT EXISTS `FactoryOrder` (
  `id_FactoryOrder` int NOT NULL AUTO_INCREMENT,
  `id_Item` int NOT NULL,
  `quantity` int NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `order_date` date NOT NULL DEFAULT (curdate()),
  PRIMARY KEY (`id_FactoryOrder`),
  KEY `id_Item` (`id_Item`),
  CONSTRAINT `FactoryOrder_ibfk_1` FOREIGN KEY (`id_Item`) REFERENCES `Item` (`id_Item`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Autres tables (Image, Mosaic, CustomerImage)
CREATE TABLE IF NOT EXISTS `Image` (
  `id_Image` int NOT NULL AUTO_INCREMENT,
  `filename` varchar(255) NOT NULL,
  PRIMARY KEY (`id_Image`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `Mosaic` (
  `id_Mosaic` int NOT NULL AUTO_INCREMENT,
  `pattern_type` varchar(50) NOT NULL,
  `generation_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_Mosaic`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `CustomerImage` (
  `id_Image` int NOT NULL AUTO_INCREMENT,
  `upload_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_Image`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `MosaicComposition` (
  `id_Mosaic` int NOT NULL,
  `id_Item` int NOT NULL,
  `quantity_needed` int NOT NULL,
  PRIMARY KEY (`id_Mosaic`,`id_Item`),
  KEY `id_Item` (`id_Item`),
  CONSTRAINT `MosaicComposition_ibfk_1` FOREIGN KEY (`id_Mosaic`) REFERENCES `Mosaic` (`id_Mosaic`),
  CONSTRAINT `MosaicComposition_ibfk_2` FOREIGN KEY (`id_Item`) REFERENCES `Item` (`id_Item`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Table CustomerOrder
CREATE TABLE IF NOT EXISTS `CustomerOrder` (
  `id_Order` int NOT NULL AUTO_INCREMENT,
  `order_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` varchar(20) NOT NULL,
  `total_amount` decimal(10,2) NOT NULL,
  `id_Customer` int NOT NULL,
  `id_Image` int DEFAULT NULL,
  `id_Mosaic` int DEFAULT NULL,
  PRIMARY KEY (`id_Order`),
  KEY `id_Customer` (`id_Customer`),
  KEY `id_Image` (`id_Image`),
  KEY `id_Mosaic` (`id_Mosaic`),
  CONSTRAINT `CustomerOrder_ibfk_1` FOREIGN KEY (`id_Customer`) REFERENCES `Customer` (`id_Customer`),
  CONSTRAINT `CustomerOrder_ibfk_2` FOREIGN KEY (`id_Image`) REFERENCES `CustomerImage` (`id_Image`),
  CONSTRAINT `CustomerOrder_ibfk_3` FOREIGN KEY (`id_Mosaic`) REFERENCES `Mosaic` (`id_Mosaic`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Table OrderItem
CREATE TABLE IF NOT EXISTS `OrderItem` (
  `id_Order` int NOT NULL,
  `id_Item` int NOT NULL,
  `quantity` int NOT NULL,
  `unit_price_snapshot` decimal(10,2) NOT NULL,
  PRIMARY KEY (`id_Order`,`id_Item`),
  KEY `id_Item` (`id_Item`),
  CONSTRAINT `OrderItem_ibfk_1` FOREIGN KEY (`id_Order`) REFERENCES `CustomerOrder` (`id_Order`),
  CONSTRAINT `OrderItem_ibfk_2` FOREIGN KEY (`id_Item`) REFERENCES `Item` (`id_Item`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Table BankDetails
CREATE TABLE IF NOT EXISTS `BankDetails` (
  `id_Bank_Details` int NOT NULL AUTO_INCREMENT,
  `id_Customer` int NOT NULL,
  `bank_name` varchar(150) NOT NULL,
  `card_number` varchar(16) NOT NULL,
  `expire_at` date NOT NULL,
  `cvc` varchar(3) NOT NULL,
  PRIMARY KEY (`id_Bank_Details`),
  KEY `id_Customer` (`id_Customer`),
  CONSTRAINT `BankDetails_ibfk_1` FOREIGN KEY (`id_Customer`) REFERENCES `Customer` (`id_Customer`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Table Invoice
CREATE TABLE IF NOT EXISTS `Invoice` (
  `id_Invoice` int NOT NULL AUTO_INCREMENT,
  `invoice_number` varchar(50) NOT NULL,
  `issue_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `total_amount` decimal(10,2) NOT NULL,
  `id_Order` int NOT NULL,
  `order_date` datetime NOT NULL,
  `order_status` varchar(20) NOT NULL,
  `id_Bank_Details` int DEFAULT NULL,
  `id_SaveCustomer` int DEFAULT NULL,
  PRIMARY KEY (`id_Invoice`),
  UNIQUE KEY `id_Order` (`id_Order`),
  KEY `id_Bank_Details` (`id_Bank_Details`),
  KEY `id_SaveCustomer` (`id_SaveCustomer`),
  CONSTRAINT `Invoice_ibfk_1` FOREIGN KEY (`id_Order`) REFERENCES `CustomerOrder` (`id_Order`),
  CONSTRAINT `Invoice_ibfk_2` FOREIGN KEY (`id_Bank_Details`) REFERENCES `BankDetails` (`id_Bank_Details`),
  CONSTRAINT `Invoice_ibfk_3` FOREIGN KEY (`id_SaveCustomer`) REFERENCES `SaveCustomer` (`id_SaveCustomer`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------
-- 3. VUES (VIEW)
-- --------------------------------------------------------

CREATE OR REPLACE VIEW `View_StockStatus` AS
SELECT 
    `i`.`id_Item` AS `id_Item`,
    `i`.`reference` AS `reference`,
    `i`.`name` AS `name`,
    (IFNULL(`entries`.`total_in`, 0) - IFNULL(`sales`.`total_out`, 0)) AS `current_stock`,
    (CASE WHEN ((IFNULL(`entries`.`total_in`, 0) - IFNULL(`sales`.`total_out`, 0)) < 10) THEN 'OUI' ELSE 'NON' END) AS `alert_status`
FROM `Item` `i`
LEFT JOIN (
    SELECT `id_Item`, SUM(`quantity`) AS `total_in`
    FROM `StockEntry`
    GROUP BY `id_Item`
) `entries` ON `i`.`id_Item` = `entries`.`id_Item`
LEFT JOIN (
    SELECT `id_Item`, SUM(`quantity`) AS `total_out`
    FROM `OrderItem`
    GROUP BY `id_Item`
) `sales` ON `i`.`id_Item` = `sales`.`id_Item`;

-- --------------------------------------------------------
-- 4. TRIGGERS (Corrigés)
-- --------------------------------------------------------

DELIMITER $$

-- Triggers FactoryOrder
DROP TRIGGER IF EXISTS `prevent_factory_order_delete`$$
CREATE TRIGGER `prevent_factory_order_delete` BEFORE DELETE ON `FactoryOrder` FOR EACH ROW BEGIN
    SIGNAL SQLSTATE '45000'
    SET MESSAGE_TEXT = 'Erreur : Il est interdit de supprimer une commande usine (FactoryOrder).';
END$$

DROP TRIGGER IF EXISTS `prevent_factory_order_update`$$
CREATE TRIGGER `prevent_factory_order_update` BEFORE UPDATE ON `FactoryOrder` FOR EACH ROW BEGIN
    SIGNAL SQLSTATE '45000'
    SET MESSAGE_TEXT = 'Erreur : Il est interdit de modifier une commande usine validée (FactoryOrder).';
END$$

-- Triggers OrderItem
DROP TRIGGER IF EXISTS `prevent_orderitem_delete`$$
CREATE TRIGGER `prevent_orderitem_delete` BEFORE DELETE ON `OrderItem` FOR EACH ROW BEGIN
    SIGNAL SQLSTATE '45000'
    SET MESSAGE_TEXT = 'Erreur : Il est interdit de supprimer une ligne de commande (Intégrité comptable).';
END$$

DROP TRIGGER IF EXISTS `prevent_orderitem_update`$$
CREATE TRIGGER `prevent_orderitem_update` BEFORE UPDATE ON `OrderItem` FOR EACH ROW BEGIN
    SIGNAL SQLSTATE '45000'
    SET MESSAGE_TEXT = 'Erreur : Il est interdit de modifier une ligne de commande validée.';
END$$

-- Triggers SaveCustomer
DROP TRIGGER IF EXISTS `prevent_savecustomer_delete`$$
CREATE TRIGGER `prevent_savecustomer_delete` BEFORE DELETE ON `SaveCustomer` FOR EACH ROW BEGIN
    SIGNAL SQLSTATE '45000'
    SET MESSAGE_TEXT = 'Erreur : Suppression interdite sur SaveCustomer (Table archivée).';
END$$

DROP TRIGGER IF EXISTS `prevent_savecustomer_update`$$
CREATE TRIGGER `prevent_savecustomer_update` BEFORE UPDATE ON `SaveCustomer` FOR EACH ROW BEGIN
    SIGNAL SQLSTATE '45000'
    SET MESSAGE_TEXT = 'Erreur : Modification interdite sur SaveCustomer (Table archivée).';
END$$

-- Triggers Invoice (Le gros morceau corrigé)
DROP TRIGGER IF EXISTS `before_invoice_insert`$$
CREATE TRIGGER `before_invoice_insert` BEFORE INSERT ON `Invoice` FOR EACH ROW BEGIN
    -- Variables
    DECLARE v_id_SaveCustomer INT;
    DECLARE v_today_prefix VARCHAR(20);
    DECLARE v_max_invoice VARCHAR(50);
    DECLARE v_next_seq INT DEFAULT 1;

    -- Récupération client
    SELECT c.id_SaveCustomer 
    INTO v_id_SaveCustomer
    FROM CustomerOrder co
    JOIN Customer c ON co.id_Customer = c.id_Customer
    WHERE co.id_Order = NEW.id_Order
    LIMIT 1; 

    SET NEW.id_SaveCustomer = v_id_SaveCustomer;

    -- Génération numéro facture
    SET v_today_prefix = CONCAT('FACT-', DATE_FORMAT(NOW(), '%Y%m%d'), '-');

    SELECT invoice_number INTO v_max_invoice
    FROM Invoice
    WHERE invoice_number LIKE CONCAT(v_today_prefix, '%')
    ORDER BY id_Invoice DESC
    LIMIT 1;

    IF v_max_invoice IS NOT NULL THEN
        SET v_next_seq = CAST(SUBSTRING_INDEX(v_max_invoice, '-', -1) AS UNSIGNED) + 1;
    END IF;

    SET NEW.invoice_number = CONCAT(v_today_prefix, LPAD(v_next_seq, 3, '0'));
END$$

DROP TRIGGER IF EXISTS `prevent_invoice_delete`$$
CREATE TRIGGER `prevent_invoice_delete` BEFORE DELETE ON `Invoice` FOR EACH ROW BEGIN
    SIGNAL SQLSTATE '45000'
    SET MESSAGE_TEXT = 'Erreur : Il est interdit de supprimer une facture existante.';
END$$

DROP TRIGGER IF EXISTS `prevent_invoice_update`$$
CREATE TRIGGER `prevent_invoice_update` BEFORE UPDATE ON `Invoice` FOR EACH ROW BEGIN
    SIGNAL SQLSTATE '45000'
    SET MESSAGE_TEXT = 'Erreur : Il est interdit de modifier une facture existante.';
END$$

DELIMITER ;

-- --------------------------------------------------------
-- 5. DONNÉES DE TEST (FIXTURES)
-- --------------------------------------------------------

INSERT INTO `Item` (`reference`, `name`, `color`, `unit_price`) VALUES
('LEGO-2X4-RED', 'Brique 2x4 Classique', 'Rouge', 0.15),
('LEGO-2X4-BLUE', 'Brique 2x4 Classique', 'Bleu', 0.15),
('LEGO-2X2-YEL', 'Brique 2x2 Standard', 'Jaune', 0.10),
('LEGO-1X1-GRY', 'Plaque 1x1 Lisse', 'Gris', 0.05),
('LEGO-1X8-BLK', 'Barre 1x8 Longue', 'Noir', 0.25),
('LEGO-WIN-2X2', 'Fenêtre 2x2', 'Transparent', 0.50),
('LEGO-DOOR-RED', 'Porte Maison', 'Rouge', 1.20);

INSERT INTO `SaveCustomer` (`first_name`, `last_name`, `email`, `adress`, `postal_code`, `city`) VALUES
('Jean', 'Admin', 'admin@sae.fr', '12 Rue du Test', '75000', 'Paris'),
('Sophie', 'Martin', 'sophie@client.fr', '45 Avenue des Champs', '69000', 'Lyon');

INSERT INTO `Customer` (`password`, `phone`, `id_SaveCustomer`) VALUES
('$2y$10$wWk1w/X.X.X.X.X.X.X.X.X.X.X.X.X.X.X.X.X.X.X.X.X.X.X', '0601020304', 1),
('$2y$10$wWk1w/X.X.X.X.X.X.X.X.X.X.X.X.X.X.X.X.X.X.X.X.X.X.X', '0708091011', 2);

INSERT INTO `StockEntry` (`id_Item`, `quantity`, `date_import`) VALUES
(1, 1000, DATE_SUB(NOW(), INTERVAL 10 DAY)), 
(2, 500, DATE_SUB(NOW(), INTERVAL 5 DAY)),  
(3, 50, NOW()),                             
(4, 2000, NOW());

INSERT INTO `Mosaic` (`pattern_type`) VALUES
('Château Fort Médiéval'),
('Vaisseau Spatial'),
('Maison de Campagne');

INSERT INTO `MosaicComposition` (`id_Mosaic`, `id_Item`, `quantity_needed`) VALUES
(1, 4, 500),
(1, 5, 50),
(1, 1, 10);

INSERT INTO `CustomerOrder` (`order_date`, `status`, `total_amount`, `id_Customer`) VALUES
(NOW(), 'Paid', 150.00, 1);

INSERT INTO `OrderItem` (`id_Order`, `id_Item`, `quantity`, `unit_price_snapshot`) VALUES
(1, 1, 5, 0.15),
(1, 3, 2, 0.10);

-- Fin du fichier
COMMIT;