Ce programme transforme une image en mosaïque LEGO,
en utilisant automatiquement des pièces 1x1 et 1x2,
en fonction de la couleur la plus proche et du stock
disponible.

Trois pavages sont produits :

- outGreedyMatching.txt : pavage rapide basé sur un matching simple
- outOptMatching.txt : pavage optimisé
- outStockAware.txt : pavage tenant compte du stock des pièces

-----
1) Compilation

Depuis le dossier contenant le fichier source :

    gcc pavage.c -o pavage -lm

-----
2) Exécution

    ./pavage dossier

où "dossier" contient :
- image.txt
- briques.txt

Les fichiers résultats sont créés dans ce même dossier.

-----
3) Format du fichier image.txt

Première ligne : largeur et hauteur

    W H

Puis W*H couleurs au format hexadécimal (6 caractères) :

    C00 C01 C02 ...
    C10 C11 C12 ...
    ...

Exemple :

    4 3
    FF0000 00FF00 0000FF FFFFFF
    000000 FF0000 00FF00 0000FF
    ...

-----
4) Format du fichier briques.txt

Première ligne :

    nbFormes nbCouleurs nbBriques

Puis la description des formes :

    largeur-hauteur[-trous]

Puis les couleurs :

    RRGGBB

Puis la liste des briques disponibles :

    indexForme/indexCouleur prix stock


Exemple simplifié :

    2 3 4
    1-1
    2-1
    FF0000 00FF00 0000FF
    0/0 1 20
    0/1 1 15
    1/1 2 10
    1/2 2 5

-----
5) Sorties générées

Chaque fichier indique :

    nbPieces totalPrix totalErreur nbRuptures

Puis une ligne par pièce :

    <forme>/<couleur> x y rotation

Exemple :

    2x1/FF0000 3 4 0

-----
6) Nettoyage

Supprimer l’exécutable :

    make clean

Rayan ESSAIDI
Projet SAE - Pavage LEGO